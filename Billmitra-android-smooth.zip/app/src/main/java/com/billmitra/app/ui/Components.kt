@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.billmitra.app.ui

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billmitra.app.data.*
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/* ---------- translations (same keys as the web app; strings.xml is generated from the web i18n) ---------- */
private val strIdCache = java.util.concurrent.ConcurrentHashMap<String, Int>()
fun strRes(ctx: Context, key: String, vararg args: Any): String {
    val id = strIdCache.getOrPut(key) { ctx.resources.getIdentifier(key.replace('.', '_'), "string", ctx.packageName) }
    if (id == 0) return key
    return if (args.isEmpty()) ctx.getString(id) else ctx.getString(id, *args)
}
fun catNameRes(ctx: Context, k: String): String = if (isCustomCat(k)) k.substring(CUSTOM_CAT_PREFIX.length) else strRes(ctx, "cat.$k")
@Composable fun catName(k: String): String = catNameRes(LocalContext.current, k)
@Composable fun tr(key: String): String = strRes(LocalContext.current, key)
@Composable fun trf(key: String, vararg args: Any): String = strRes(LocalContext.current, key, *args)

@Composable
fun fmtDate(s: String): String {
    val loc = LocalContext.current.resources.configuration.locales[0]
    return try { LocalDate.parse(s).format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(loc)) } catch (e: Exception) { s }
}

fun animationsEnabled(ctx: Context): Boolean = Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
/** Same as [animationsEnabled] but read once per composition scope instead of on every recomposition. */
@Composable fun rememberAnimationsEnabled(): Boolean { val ctx = LocalContext.current; return remember(ctx) { animationsEnabled(ctx) } }
@Composable fun animMs(ms: Int): Int = if (rememberAnimationsEnabled()) ms else 0

/** Long lists show this many rows first; "Show more" adds another page (keeps screens fast with thousands of bills). */
const val PAGE_SIZE = 20   // rows are composed eagerly inside one card, so a smaller first page keeps tab switches and scrolling smooth
@Composable
fun ShowMore(total: Int, shown: Int, onMore: () -> Unit) {
    if (total > shown) TextButton(onMore, Modifier.fillMaxWidth()) { Text(tr("common.showMore") + " (" + (total - shown) + ")") }
}

/* ---------- surfaces ---------- */
@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val border = BorderStroke(1.dp, LocalExtra.current.line)
    if (onClick != null) Card(onClick, modifier.fillMaxWidth(), shape = shape, colors = colors, border = border, elevation = CardDefaults.cardElevation(2.dp)) { Column(Modifier.padding(16.dp), content = content) }
    else Card(modifier.fillMaxWidth(), shape = shape, colors = colors, border = border, elevation = CardDefaults.cardElevation(2.dp)) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun NavyCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Navy, Royal))).padding(18.dp), content = content)
}

@Composable
fun Page(title: String, onBack: (() -> Unit)? = null, fab: (@Composable () -> Unit)? = null, content: LazyListScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 104.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) IconButton(onBack) { Icon(Icons.Outlined.ArrowBack, tr("common.back")) }
                    Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            content()
        }
        if (fab != null) Box(Modifier.align(Alignment.BottomEnd).padding(18.dp)) { fab() }
    }
}

@Composable
fun GradientFab(icon: ImageVector, desc: String, onClick: () -> Unit) {
    FloatingActionButton(onClick, containerColor = Royal, contentColor = Color.White, shape = RoundedCornerShape(18.dp)) { Icon(icon, desc) }
}

@Composable
fun SectionTitle(text: String, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium); action?.invoke()
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, sub: String? = null) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(title, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        if (sub != null) Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun StatusChip(status: PayStatus) {
    val x = LocalExtra.current
    val (bg, fg, key) = when (status) { PayStatus.PAID -> Triple(x.greenBg, x.green, "status.paid"); PayStatus.PARTIAL -> Triple(x.amberBg, x.amber, "status.partial"); PayStatus.UNPAID -> Triple(x.redBg, x.red, "status.unpaid") }
    Text(tr(key), color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(bg).padding(horizontal = 10.dp, vertical = 3.dp))
}

@Composable
fun IconBadge(icon: ImageVector, bg: Color, fg: Color, round: Boolean = false) {
    Box(Modifier.size(40.dp).clip(if (round) CircleShape else RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)) }
}

@Composable
fun ListRow(icon: ImageVector?, iconBg: Color, iconFg: Color, title: String, subtitle: String?, trailing: @Composable (ColumnScope.() -> Unit)? = null, onClick: (() -> Unit)? = null, leadingText: String? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if (icon != null) IconBadge(icon, iconBg, iconFg)
        else Box(Modifier.size(40.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) { Text(leadingText ?: "", color = Color.White, fontWeight = FontWeight.Bold) }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp), content = trailing)
    }
}

@Composable
fun KV(label: String, value: String, color: Color = Color.Unspecified, big: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = if (big) 18.sp else 15.sp)
    }
}

/** Number that counts smoothly to its new value (skipped when system animations are off). */
@Composable
fun AnimatedMoney(value: Long, color: Color = Color.Unspecified, size: Int = 20, weight: FontWeight = FontWeight.Bold) {
    var shown by remember { mutableLongStateOf(value) }
    val enabled = rememberAnimationsEnabled()
    LaunchedEffect(value) {
        if (!enabled) { shown = value; return@LaunchedEffect }
        val start = shown
        if (start == value) return@LaunchedEffect   // first composition / unchanged: nothing to animate
        Animatable(0f).animateTo(1f, tween(280, easing = FastOutSlowInEasing)) { shown = start + ((value - start) * this.value).toLong() }
        shown = value
    }
    Text(Money.format(shown), color = color, fontSize = size.sp, fontWeight = weight)
}

/* ---------- inputs ---------- */
@Composable
fun AppField(label: String, value: String, onValue: (String) -> Unit, error: String? = null, keyboard: KeyboardType = KeyboardType.Text,
             singleLine: Boolean = true, optional: Boolean = false, modifier: Modifier = Modifier, maxLen: Int = 300, readOnly: Boolean = false) {
    OutlinedTextField(value, { if (it.length <= maxLen) onValue(it) }, modifier.fillMaxWidth(), label = { Text(if (optional) "$label (${tr("common.optional")})" else label) },
        isError = error != null, supportingText = if (error != null) ({ Text(error) }) else null, singleLine = singleLine, minLines = if (singleLine) 1 else 2,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard), shape = RoundedCornerShape(12.dp), readOnly = readOnly)
}

@Composable
fun MoneyField(label: String, value: String, onValue: (String) -> Unit, error: String?, modifier: Modifier = Modifier) =
    AppField("$label (₹)", value, { s -> if (s.all { it.isDigit() || it == '.' || it == ',' }) onValue(s) }, error, KeyboardType.Decimal, modifier = modifier, maxLen = 16)

@Composable
fun DateField(label: String, value: String, onValue: (String) -> Unit, error: String? = null, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(value, {}, Modifier.fillMaxWidth(), label = { Text(label) }, readOnly = true, singleLine = true, isError = error != null,
            supportingText = if (error != null) ({ Text(error) }) else null, shape = RoundedCornerShape(12.dp),
            trailingIcon = { Icon(Icons.Outlined.CalendarMonth, null) })
        Box(Modifier.matchParentSize().clickable { open = true }.semantics { contentDescription = label })
    }
    if (open) {
        val init = runCatching { LocalDate.parse(value).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli() }.getOrNull()
        val st = rememberDatePickerState(initialSelectedDateMillis = init)
        DatePickerDialog(onDismissRequest = { open = false },
            confirmButton = { TextButton({ st.selectedDateMillis?.let { onValue(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }; open = false }) { Text(tr("common.confirm")) } },
            dismissButton = { TextButton({ open = false }) { Text(tr("common.cancel")) } }) { DatePicker(st) }
    }
}

@Composable
fun ChoiceChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (k, label) -> FilterChip(selected == k, { onSelect(k) }, label = { Text(label) }, shape = RoundedCornerShape(99.dp)) }
    }
}

@Composable
fun SearchBox(value: String, onValue: (String) -> Unit, hint: String) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), placeholder = { Text(hint, maxLines = 1, overflow = TextOverflow.Ellipsis) }, singleLine = true,
        leadingIcon = { Icon(Icons.Outlined.Search, null) }, shape = RoundedCornerShape(14.dp),
        trailingIcon = if (value.isNotEmpty()) ({ IconButton({ onValue("") }) { Icon(Icons.Outlined.Close, tr("common.clear")) } }) else null)
}

@Composable
fun PrimaryButton(text: String, icon: ImageVector? = null, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.heightIn(min = 46.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Royal, contentColor = Color.White)) {
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }; Text(text)
    }
}
@Composable
fun SoftButton(text: String, icon: ImageVector? = null, danger: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick, modifier.heightIn(min = 46.dp), shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.filledTonalButtonColors(contentColor = if (danger) LocalExtra.current.red else MaterialTheme.colorScheme.onSurface)) {
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }; Text(text)
    }
}

/* ---------- sheets, dialogs, feedback ---------- */
@Composable
fun FormSheet(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontSize = 19.sp)
                IconButton(onDismiss) { Icon(Icons.Outlined.Close, tr("common.close")) }
            }
            content()
        }
    }
}

@Composable
fun FormButtons(onCancel: () -> Unit, onSave: () -> Unit, extra: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End), verticalAlignment = Alignment.CenterVertically) {
        extra?.invoke(); Spacer(Modifier.weight(1f))
        TextButton(onCancel) { Text(tr("common.cancel")) }
        PrimaryButton(tr("common.save"), onClick = onSave)
    }
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmText: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(message) }, shape = RoundedCornerShape(20.dp),
        confirmButton = { TextButton({ onConfirm(); onDismiss() }) { Text(confirmText, color = LocalExtra.current.red, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onDismiss) { Text(tr("common.cancel")) } })
}

/** Green tick that pops in, shown after saving a bill / payment / expense. */
@Composable
fun SuccessOverlay(messageKey: String?, onDone: () -> Unit) {
    val animOn = rememberAnimationsEnabled()
    val scale = remember { Animatable(0.8f) }
    var lastKey by remember { mutableStateOf("") }   // keeps the text visible while the overlay fades out
    LaunchedEffect(messageKey) { if (messageKey != null) { delay(1000); onDone() } }
    LaunchedEffect(messageKey) {
        if (messageKey != null) {
            lastKey = messageKey
            if (animOn) { scale.snapTo(0.8f); scale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 300f)) } else scale.snapTo(1f)
        }
    }
    AnimatedVisibility(messageKey != null, enter = fadeIn(tween(animMs(180))), exit = fadeOut(tween(animMs(200)))) {
        Box(Modifier.fillMaxSize().background(Color(0x59060D1E)), contentAlignment = Alignment.Center) {
            // scale is read inside the graphics layer, so the pop never triggers recomposition
            Column(Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value }.clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface).padding(horizontal = 36.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(LocalExtra.current.green), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Check, null, Modifier.size(38.dp), tint = Color.White) }
                Text(tr(messageKey ?: lastKey), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PinPad(title: String, entry: String, onKey: (String) -> Unit, extra: (@Composable () -> Unit)? = null) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { repeat(4) { i -> Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < entry.length) Royal else MaterialTheme.colorScheme.surfaceVariant)) } }
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "del")).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                r.forEach { k ->
                    if (k.isEmpty()) Spacer(Modifier.size(68.dp)) else
                        Box(Modifier.size(68.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onKey(k) }.semantics { contentDescription = if (k == "del") "delete" else k }, contentAlignment = Alignment.Center) {
                            if (k == "del") Icon(Icons.Outlined.Backspace, null) else Text(k, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                        }
                }
            }
        }
        extra?.invoke()
    }
}
