@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.runtime.saveable.rememberSaveable
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.FragmentActivity
import com.billmitra.app.data.*
import com.billmitra.app.util.Csv
import com.billmitra.app.util.Share
import com.billmitra.app.util.SimplePdf
import java.time.LocalDate
import kotlinx.coroutines.launch
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

/* ---------------- settings home ---------------- */
@Composable
fun SettingsScreen(vm: AppViewModel, nav: Nav) {
    val lang = currentLang()
    val items = listOf(
        Triple(Icons.Outlined.History, "set.payments", "settings/payments"), Triple(Icons.Outlined.BarChart, "set.reports", "settings/reports"),
        Triple(Icons.Outlined.Business, "set.profile", "settings/profile"), Triple(Icons.Outlined.Notifications, "set.reminders", "settings/reminders"),
        Triple(Icons.Outlined.Language, "set.language", "settings/language"), Triple(if (vm.theme == "dark") Icons.Outlined.DarkMode else Icons.Outlined.LightMode, "set.appearance", "settings/appearance"),
        Triple(Icons.Outlined.Security, "set.privacy", "settings/privacy"), Triple(Icons.Outlined.Backup, "set.backup", "settings/backup"),
        Triple(Icons.Outlined.FileDownload, "set.export", "settings/export"), Triple(Icons.Outlined.Info, "set.about", "settings/about"))
    Page(tr("nav.settings")) {
        item {
            AppCard {
                items.forEach { (icon, key, route) ->
                    val value = when (key) { "set.profile" -> vm.profile.name; "set.language" -> if (lang == "hi") "हिन्दी" else "English"; "set.appearance" -> tr("theme." + vm.theme); "set.privacy" -> if (vm.hasPin) tr("priv.on") else ""; else -> "" }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { nav.go(route) }.padding(vertical = 12.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        IconBadge(icon, MaterialTheme.colorScheme.surfaceVariant, Royal)
                        Text(tr(key), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        if (value.isNotBlank()) Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

fun currentLang(): String {
    val l = AppCompatDelegate.getApplicationLocales()
    return if (!l.isEmpty) l[0]?.language ?: "en" else java.util.Locale.getDefault().language
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = if (selected) Royal else Color.Unspecified)
        if (selected) Icon(Icons.Outlined.Check, null, tint = Royal)
    }
}

@Composable
fun LanguageScreen(nav: Nav) {
    val cur = currentLang()
    Page(tr("set.language"), onBack = nav.back) {
        item {
            AppCard {
                OptionRow("English", cur != "hi") { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en")) }
                HorizontalDivider()
                OptionRow("हिन्दी", cur == "hi") { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("hi")) }
            }
        }
    }
}

@Composable
fun AppearanceScreen(vm: AppViewModel, nav: Nav) {
    Page(tr("set.appearance"), onBack = nav.back) {
        item { AppCard { listOf("light", "dark", "system").forEachIndexed { i, k -> if (i > 0) HorizontalDivider(); OptionRow(tr("theme.$k"), vm.theme == k) { vm.setTheme(k) } } } }
    }
}

@Composable
fun AboutScreen(nav: Nav) {
    Page(tr("set.about"), onBack = nav.back) {
        item {
            AppCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(Navy), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Description, null, tint = Color.White, modifier = Modifier.size(40.dp)) }
                    Text(tr("app.name"), style = MaterialTheme.typography.titleLarge)
                    Text(tr("about.tag"), color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    KV(tr("about.version"), "1.0.0")
                    Text(tr("about.text"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

/* ---------------- profile ---------------- */
@Composable
fun ProfileScreen(vm: AppViewModel, nav: Nav) {
    val p = vm.profile; val ctx = LocalContext.current
    var name by remember { mutableStateOf(p.name) }; var owner by remember { mutableStateOf(p.owner) }; var phone by remember { mutableStateOf(p.phone) }
    var email by remember { mutableStateOf(p.email) }; var address by remember { mutableStateOf(p.address) }; var gstin by remember { mutableStateOf(p.gstin) }
    var upi by remember { mutableStateOf(p.upi) }; var prefix by remember { mutableStateOf(p.prefix) }; var rate by remember { mutableStateOf(Money.toInput(p.rateBp)) }
    var gst by remember { mutableStateOf(p.gst) }; var footer by remember { mutableStateOf(p.footer) }
    var errs by remember { mutableStateOf(mapOf<String, String>()) }
    Page(tr("set.profile"), onBack = nav.back) {
        item {
            AppCard {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppField(tr("profile.name"), name, { name = it }, errs["name"], maxLen = 80); AppField(tr("profile.owner"), owner, { owner = it }, maxLen = 80)
                    AppField(tr("profile.phone"), phone, { phone = it }, errs["phone"], KeyboardType.Phone, maxLen = 20); AppField(tr("profile.email"), email, { email = it }, errs["email"], KeyboardType.Email, maxLen = 80)
                    AppField(tr("cust.address"), address, { address = it }, singleLine = false, maxLen = 200)
                    AppField(tr("tax.gstin"), gstin, { gstin = it.uppercase() }, errs["gstin"], maxLen = 15); AppField(tr("profile.upi"), upi, { upi = it }, maxLen = 60)
                    AppField(tr("profile.prefix"), prefix, { prefix = it }, errs["prefix"], maxLen = 8)
                    Text(tr("profile.defTax"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ChoiceChips(listOf("none" to tr("bill.noGst"), "gst" to tr("tax.gst")), if (gst) "gst" else "none") { gst = it == "gst" }
                    AppField(tr("profile.defRate") + " (%)", rate, { v -> if (v.all { it.isDigit() || it == '.' }) rate = v }, errs["rate"], KeyboardType.Decimal, maxLen = 6)
                    AppField(tr("profile.footer"), footer, { footer = it }, singleLine = false, maxLen = 200)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        PrimaryButton(tr("common.save")) {
                            val e = mutableMapOf<String, String>(); val r = Money.parse(rate.ifBlank { "0" })
                            if (name.isBlank()) e["name"] = strRes(ctx, "err.name")
                            if (gstin.isNotBlank() && !GSTIN_RE.matches(gstin.trim())) e["gstin"] = strRes(ctx, "err.gstin")
                            if (phone.isNotBlank() && !PHONE_RE.matches(phone.replace(" ", "").replace("-", ""))) e["phone"] = strRes(ctx, "err.phone")
                            if (email.isNotBlank() && !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) e["email"] = strRes(ctx, "err.email")
                            if (prefix.isBlank()) e["prefix"] = strRes(ctx, "err.prefix")
                            if (r == null || r > 10000) e["rate"] = strRes(ctx, "err.rate")
                            errs = e
                            if (e.isEmpty()) vm.saveProfile(Profile(name.trim(), owner.trim(), phone.trim(), email.trim(), address.trim(), gstin.trim(), upi.trim(), prefix.trim(), gst, r!!, footer.trim()))
                        }
                    }
                }
            }
        }
    }
}

/* ---------------- reminders ---------------- */
data class Overdue(val customerId: String, val due: Long, val oldest: String)

fun overdueList(bills: List<Bill>, ledger: Ledger, afterDays: Int): List<Overdue> {
    val today = LocalDate.now()
    return bills.filter { ledger.due(it) > 0 && ChronoUnit.DAYS.between(LocalDate.parse(it.date), today) >= afterDays }
        .groupBy { it.customerId }.map { (cid, l) -> Overdue(cid, l.sumOf { ledger.due(it) }, l.minOf { it.date }) }.sortedBy { it.oldest }
}

@Composable
fun RemindersScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    var on by remember { mutableStateOf(vm.reminders.enabled) }; var days by remember { mutableStateOf(vm.reminders.afterDays.toString()) }
    var err by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    val od = overdueList(bills, ledger, vm.reminders.afterDays)
    Page(tr("set.reminders"), onBack = nav.back) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(tr("rem.enable"), Modifier.weight(1f)); Switch(on, { on = it }) }
                AppField(tr("rem.after"), days, { if (it.all(Char::isDigit)) days = it }, err, KeyboardType.Number, maxLen = 3)
                Text(tr("rem.afterHint"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                    PrimaryButton(tr("common.save")) { val d = days.toIntOrNull(); if (d == null || d !in 1..365) err = strRes(ctx, "err.days") else { err = null; vm.saveReminders(ReminderCfg(on, d)) } }
                }
            }
        }
        item {
            AppCard {
                SectionTitle(tr("rem.overdue"))
                if (od.isEmpty()) EmptyState(Icons.Outlined.Check, tr("rem.none"))
                od.forEach { o ->
                    val c = ledger.customer(o.customerId)
                    ListRow(null, Color.Unspecified, Color.Unspecified, c?.name ?: tr("common.unknown"), trf("rem.since", o.oldest), leadingText = (c?.name ?: "?").take(1).uppercase(),
                        trailing = { Text(Money.format(o.due), color = LocalExtra.current.red, fontWeight = FontWeight.Bold) }, onClick = { nav.customer(o.customerId) })
                }
            }
        }
    }
}

/* ---------------- payment history ---------------- */
@Composable
fun PaymentHistoryScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    var tab by rememberSaveable { mutableStateOf("all") }; var group by rememberSaveable { mutableStateOf(false) }
    var q by rememberSaveable { mutableStateOf("") }; var from by rememberSaveable { mutableStateOf("") }; var to by rememberSaveable { mutableStateOf("") }
    var detail by remember { mutableStateOf<Payment?>(null) }
    val unknown = tr("common.unknown"); val ex = LocalExtra.current
    val billNo = remember(bills) { bills.associate { it.id to it.no } }
    var shown by remember(tab, group, q, from, to) { mutableIntStateOf(PAGE_SIZE) }
    val list = remember(payments, ledger, tab, from, to, q, unknown) { payments.filter { p ->
        (tab == "all" || (tab == "cash" && p.method == "cash") || (tab == "online" && p.method != "cash")) && (from.isEmpty() || p.date >= from) && (to.isEmpty() || p.date <= to) &&
            (q.isBlank() || (ledger.customerName(p.customerId, unknown) + " " + (billNo[p.billId] ?: "") + " " + p.ref + " " + p.notes).contains(q.trim(), true))
    } }
    @Composable fun PayRow(p: Payment) = ListRow(if (p.method == "cash") Icons.Outlined.Payments else Icons.Outlined.PhoneAndroid, ex.greenBg, ex.green, ledger.customerName(p.customerId, unknown),
        fmtDate(p.date) + " · " + tr("method." + p.method) + (billNo[p.billId]?.let { " · $it" } ?: ""), trailing = { Text(Money.format(p.amount), color = ex.green, fontWeight = FontWeight.Bold) }, onClick = { detail = p })
    Page(tr("set.payments"), onBack = nav.back) {
        item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("all", "cash", "online").forEach { k -> FilterChip(tab == k, { tab = k }, label = { Text(tr("payTab.$k")) }, shape = RoundedCornerShape(99.dp)) }; FilterChip(group, { group = !group }, label = { Text(tr("payTab.byCust")) }, shape = RoundedCornerShape(99.dp)) } }
        item { SearchBox(q, { q = it }, tr("pay.search")) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                DateField(tr("common.from"), from, { from = it }, modifier = Modifier.weight(1f)); DateField(tr("common.to"), to, { to = it }, modifier = Modifier.weight(1f))
                if (from.isNotEmpty() || to.isNotEmpty()) IconButton({ from = ""; to = "" }) { Icon(Icons.Outlined.Close, tr("common.clear")) }
            }
        }
        item {
            AppCard(Modifier.animateContentSize()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(trf("pay.count", list.size.toString()), color = MaterialTheme.colorScheme.onSurfaceVariant); Text(Money.format(list.sumOf { it.amount }), fontWeight = FontWeight.Bold) }
                if (list.isEmpty()) EmptyState(Icons.Outlined.Inbox, if (payments.isEmpty()) tr("pay.none") else tr("common.noResults"))
                if (!group) { list.take(shown).forEach { PayRow(it) }; ShowMore(list.size, shown) { shown += PAGE_SIZE } } else list.groupBy { it.customerId }.entries.sortedByDescending { e -> e.value.sumOf { it.amount } }.forEach { (cid, l) ->
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(ledger.customerName(cid, unknown), color = Royal, fontWeight = FontWeight.Bold); Text(Money.format(l.sumOf { it.amount }), fontWeight = FontWeight.Bold) }
                    l.forEach { PayRow(it) }
                }
            }
        }
    }
    detail?.let { p ->
        val b = bills.firstOrNull { it.id == p.billId }
        AlertDialog(onDismissRequest = { detail = null }, title = { Text(tr("pay.details")) }, shape = RoundedCornerShape(20.dp), text = {
            Column { KV(tr("pay.amount"), Money.format(p.amount)); KV(tr("bill.customer"), ledger.customerName(p.customerId, unknown)); KV(tr("bill.no"), b?.no ?: "–"); KV(tr("pay.date"), p.date)
                KV(tr("pay.method"), tr("method." + p.method)); KV(tr("pay.ref"), p.ref.ifBlank { "–" }); KV(tr("pay.notes"), p.notes.ifBlank { "–" }) } },
            confirmButton = { if (b != null) TextButton({ detail = null; nav.bill(b.id) }) { Text(tr("pay.openBill")) } }, dismissButton = { TextButton({ detail = null }) { Text(tr("common.close")) } })
    }
}

/* ---------------- reports ---------------- */
private data class Day(val date: String, var sales: Long = 0, var cash: Long = 0, var online: Long = 0, var exp: Long = 0)
private class Rep(val sales: Long, val nBills: Int, val cash: Long, val online: Long, val exp: Long, val cashExp: Long, val onlineExp: Long, val dueOnPeriod: Long, val outstanding: Long, val days: List<Day>) {
    val received get() = cash + online
    val netFlow get() = received - exp
}
private fun buildRep(bills: List<Bill>, pays: List<Payment>, exps: List<Expense>, ledger: Ledger, from: String, to: String): Rep {
    fun ok(d: String) = d in from..to
    val m = sortedMapOf<String, Day>()
    fun day(d: String) = m.getOrPut(d) { Day(d) }
    val b = bills.filter { ok(it.date) }; b.forEach { day(it.date).sales += it.finalAmount }
    val p = pays.filter { ok(it.date) }; p.forEach { if (it.method == "cash") day(it.date).cash += it.amount else day(it.date).online += it.amount }
    val e = exps.filter { ok(it.date) }; e.forEach { day(it.date).exp += it.amount }
    return Rep(b.sumOf { it.finalAmount }, b.size, p.filter { it.method == "cash" }.sumOf { it.amount }, p.filter { it.method != "cash" }.sumOf { it.amount }, e.sumOf { it.amount },
        e.filter { it.method == "cash" }.sumOf { it.amount }, e.filter { it.method != "cash" }.sumOf { it.amount }, b.sumOf { ledger.due(it) }, ledger.outstanding, m.values.toList())
}

@Composable
fun ReportsScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val expenses by vm.expenses.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    var mode by rememberSaveable { mutableStateOf("daily") }; var anchor by rememberSaveable { mutableStateOf(today()) }
    var cFrom by rememberSaveable { mutableStateOf(today()) }; var cTo by rememberSaveable { mutableStateOf(today()) }
    val ctx = LocalContext.current; val ex = LocalExtra.current
    val a = LocalDate.parse(anchor)
    val (from, to) = when (mode) {
        "daily" -> a.toString() to a.toString()
        "weekly" -> a.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).let { it.toString() to it.plusDays(6).toString() }
        "monthly" -> a.withDayOfMonth(1).toString() to a.withDayOfMonth(a.lengthOfMonth()).toString()
        else -> cFrom to cTo
    }
    val invalid = from > to
    val r = if (invalid) null else buildRep(bills, payments, expenses, ledger, from, to)
    fun shift(n: Long) { anchor = when (mode) { "daily" -> a.plusDays(n); "weekly" -> a.plusWeeks(n); else -> a.plusMonths(n) }.toString() }
    Page(tr("set.reports"), onBack = nav.back) {
        item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("daily", "weekly", "monthly", "custom").forEach { k -> FilterChip(mode == k, { mode = k }, label = { Text(tr("rep.$k")) }, shape = RoundedCornerShape(99.dp)) } } }
        item {
            if (mode == "custom") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { DateField(tr("common.from"), cFrom, { cFrom = it }, modifier = Modifier.weight(1f)); DateField(tr("common.to"), cTo, { cTo = it }, modifier = Modifier.weight(1f)) }
            else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton({ shift(-1) }) { Icon(Icons.Outlined.ChevronRight, tr("rep.prev"), Modifier.rotate(180f)) }
                DateField(tr("pay.date"), anchor, { anchor = it }, modifier = Modifier.weight(1f))
                IconButton({ shift(1) }) { Icon(Icons.Outlined.ChevronRight, tr("rep.next")) }
            }
        }
        if (r == null) item { Text(tr("rep.badRange"), color = ex.amber) } else {
            item { NavyCard { Text(if (from == to) fmtDateRaw(from, ctx) else fmtDateRaw(from, ctx) + " – " + fmtDateRaw(to, ctx), color = Color.White.copy(alpha = .85f)); AnimatedMoney(r.received, Color.White, 30); Text(tr("rep.collected") + "  ·  " + tr("rep.sales") + ": " + Money.format(r.sales), color = Color.White.copy(alpha = .9f), fontSize = 13.sp) } }
            item {
                AppCard {
                    KV(tr("rep.sales") + " (" + trf("rep.billsCount", r.nBills.toString()) + ")", Money.format(r.sales)); KV(tr("rep.collected"), Money.format(r.received), ex.green)
                    KV("   " + tr("rep.cashIn"), Money.format(r.cash)); KV("   " + tr("rep.onlineIn"), Money.format(r.online)); KV(tr("rep.expenses"), Money.format(r.exp), ex.red)
                    KV(tr("rep.dueOnPeriod"), Money.format(r.dueOnPeriod)); KV(tr("rep.outstanding") + " (" + tr("rep.allTime") + ")", Money.format(r.outstanding), ex.red)
                }
            }
            item {
                AppCard {
                    SectionTitle(tr("rep.cashflow"))
                    KV(tr("rep.cashNet"), Money.format(r.cash - r.cashExp)); KV(tr("rep.onlineNet"), Money.format(r.online - r.onlineExp)); KV(tr("rep.netFlow"), Money.format(r.netFlow), if (r.netFlow < 0) ex.red else ex.green, true)
                    Text(tr("rep.profitNote"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                }
            }
            if (r.days.isNotEmpty()) item {
                AppCard {
                    SectionTitle(tr("rep.daywise"))
                    r.days.forEach { d -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text(fmtDateRaw(d.date, ctx), Modifier.weight(1.3f), fontSize = 12.sp); Text(Money.format(d.sales), Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End)
                        Text(Money.format(d.cash + d.online), Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End, color = ex.green); Text(Money.format(d.exp), Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End) } }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(tr("rep.pdf"), Icons.Outlined.Print, Modifier.weight(1f)) { Share.file(ctx, "billmitra-report-$from-$to.pdf", "application/pdf", reportPdf(ctx, vm.profile, r, from, to), strRes(ctx, "rep.pdf")) }
                    SoftButton(tr("rep.csv"), Icons.Outlined.FileDownload, modifier = Modifier.weight(1f)) {
                        val rows = mutableListOf<List<Any?>>(listOf(strRes(ctx, "rep.period"), "$from → $to"), listOf(strRes(ctx, "rep.sales"), Money.toInput(r.sales)), listOf(strRes(ctx, "rep.billsN"), r.nBills),
                            listOf(strRes(ctx, "rep.collected"), Money.toInput(r.received)), listOf(strRes(ctx, "rep.cashIn"), Money.toInput(r.cash)), listOf(strRes(ctx, "rep.onlineIn"), Money.toInput(r.online)),
                            listOf(strRes(ctx, "rep.expenses"), Money.toInput(r.exp)), listOf(strRes(ctx, "rep.dueOnPeriod"), Money.toInput(r.dueOnPeriod)), listOf(strRes(ctx, "rep.outstanding"), Money.toInput(r.outstanding)),
                            listOf(strRes(ctx, "rep.netFlow"), Money.toInput(r.netFlow)), emptyList(), listOf(strRes(ctx, "rep.date"), strRes(ctx, "rep.sales"), strRes(ctx, "rep.cashIn"), strRes(ctx, "rep.onlineIn"), strRes(ctx, "rep.expenses")))
                        r.days.forEach { rows += listOf(it.date, Money.toInput(it.sales), Money.toInput(it.cash), Money.toInput(it.online), Money.toInput(it.exp)) }
                        Share.file(ctx, "billmitra-report-$from-$to.csv", "text/csv", Csv.build(rows).toByteArray(), strRes(ctx, "rep.csv"))
                    }
                }
            }
        }
    }
}
private fun fmtDateRaw(s: String, ctx: Context): String = try { LocalDate.parse(s).format(java.time.format.DateTimeFormatter.ofLocalizedDate(java.time.format.FormatStyle.MEDIUM).withLocale(ctx.resources.configuration.locales[0])) } catch (e: Exception) { s }

private fun reportPdf(ctx: Context, p: Profile, r: Rep, from: String, to: String): ByteArray {
    val s = { k: String -> strRes(ctx, k) }
    val pdf = SimplePdf()
    pdf.line(p.name.ifBlank { s("app.name") }, big = true); pdf.line(s("set.reports") + ": " + from + " – " + to, boldText = true); pdf.rule()
    pdf.row(s("rep.sales"), Money.format(r.sales)); pdf.row(s("rep.collected"), Money.format(r.received), true); pdf.row("  " + s("rep.cashIn"), Money.format(r.cash)); pdf.row("  " + s("rep.onlineIn"), Money.format(r.online))
    pdf.row(s("rep.expenses"), Money.format(r.exp)); pdf.row(s("rep.dueOnPeriod"), Money.format(r.dueOnPeriod)); pdf.row(s("rep.outstanding"), Money.format(r.outstanding))
    pdf.row(s("rep.netFlow"), Money.format(r.netFlow), true); pdf.space(); pdf.line(s("rep.profitNote"), mutedText = true); pdf.space(); pdf.rule()
    pdf.line(s("rep.daywise"), boldText = true)
    r.days.forEach { pdf.row(it.date + "   " + Money.format(it.sales), Money.format(it.cash + it.online) + "   " + Money.format(it.exp)) }
    return pdf.toBytes()
}

/* ---------------- export ---------------- */
@Composable
fun ExportScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState(); val expenses by vm.expenses.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    val ctx = LocalContext.current; val unknown = tr("common.unknown")
    var pending by remember { mutableStateOf("") }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            val s = { k: String -> strRes(ctx, k) }
            val rows: List<List<Any?>> = when (pending) {
                "bills" -> listOf(listOf("bill.no", "bill.date", "bill.customer", "bill.description", "bill.amount", "bill.discount", "csv.tax", "bill.final", "bill.received", "bill.due", "bill.status").map(s)) +
                    bills.map { listOf(it.no, it.date, ledger.customerName(it.customerId, unknown), it.description, Money.toInput(it.amount), Money.toInput(it.discount), Money.toInput(it.tax), Money.toInput(it.finalAmount), Money.toInput(ledger.paid(it)), Money.toInput(ledger.due(it)), s("status." + ledger.status(it).name.lowercase())) }
                "payments" -> listOf(listOf("pay.date", "bill.customer", "bill.no", "pay.method", "pay.amount", "pay.ref", "pay.notes").map(s)) +
                    payments.map { p -> listOf(p.date, ledger.customerName(p.customerId, unknown), bills.firstOrNull { it.id == p.billId }?.no ?: "", s("method." + p.method), Money.toInput(p.amount), p.ref, p.notes) }
                "customers" -> listOf(listOf("cust.name", "cust.phone", "cust.address", "cust.billed", "bill.received", "cust.outstanding").map(s)) +
                    customers.map { c -> listOf(c.name, c.phone, c.address, Money.toInput(ledger.customerBilled(c.id)), Money.toInput(ledger.customerPaid(c.id)), Money.toInput(ledger.customerDue(c.id))) }
                else -> listOf(listOf("pay.date", "exp.category", "exp.amount", "pay.method", "pay.notes").map(s)) + expenses.map { e -> listOf(e.date, catNameRes(ctx, e.category), Money.toInput(e.amount), s(if (e.method == "cash") "method.cash" else "exp.online"), e.notes) }
            }
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(Csv.build(rows).toByteArray()) }; vm.toast("ok.exported")
        }
    }
    Page(tr("set.export"), onBack = nav.back) {
        item { Text(tr("exp2.lead"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            AppCard { listOf("bills", "payments", "customers", "expenses").forEachIndexed { i, k -> if (i > 0) HorizontalDivider()
                Row(Modifier.fillMaxWidth().clickable { pending = k; saver.launch("billmitra-$k-${today()}.csv") }.padding(vertical = 14.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconBadge(Icons.Outlined.FileDownload, MaterialTheme.colorScheme.surfaceVariant, Royal); Text(tr("exp2.$k"), Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("CSV", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        }
    }
}

/* ---------------- backup & restore ---------------- */
@Composable
fun BackupScreen(vm: AppViewModel, nav: Nav) {
    val ctx = LocalContext.current
    val customers by vm.customers.collectAsState(); val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val expenses by vm.expenses.collectAsState()
    var pendingText by remember { mutableStateOf<String?>(null) }; var pendingInfo by remember { mutableStateOf<Backup.Parsed?>(null) }
    val scope = rememberCoroutineScope()
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { val json = vm.exportBackup(); ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } }.onSuccess { vm.toast("ok.exported") }.onFailure { vm.toast("err.save", true) } }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.use { s -> if (s.available() > 30_000_000) null else s.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
            if (text == null) vm.toast("bk.err.corrupt", true) else { val (parsed, err) = vm.preview(text); if (parsed == null) vm.toast("bk.err.$err", true) else { pendingText = text; pendingInfo = parsed } }
        }
    }
    Page(tr("set.backup"), onBack = nav.back) {
        item {
            AppCard {
                Text(tr("bk.export"), style = MaterialTheme.typography.titleMedium); Text(tr("bk.exportHint"), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                KV(tr("nav.customers"), customers.size.toString()); KV(tr("nav.bills"), bills.size.toString()); KV(tr("set.payments"), payments.size.toString()); KV(tr("nav.expenses"), expenses.size.toString())
                PrimaryButton(tr("bk.export"), Icons.Outlined.FileDownload, Modifier.fillMaxWidth()) { saver.launch("billmitra-backup-${today()}.json") }
            }
        }
        item {
            AppCard {
                Text(tr("bk.import"), style = MaterialTheme.typography.titleMedium); Text(tr("bk.importHint"), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp)); SoftButton(tr("bk.choose"), Icons.Outlined.FileUpload, modifier = Modifier.fillMaxWidth()) { picker.launch(arrayOf("application/json", "text/plain", "*/*")) }
            }
        }
    }
    val info = pendingInfo; val text = pendingText
    if (info != null && text != null) ConfirmDialog(tr("bk.confirmTitle"), trf("bk.confirmMsg", info.customers.size.toString(), info.bills.size.toString(), info.payments.size.toString(), info.expenses.size.toString(), customers.size.toString(), bills.size.toString()),
        tr("bk.restore"), { vm.restore(text) { err -> if (err != null) vm.toast("bk.err.$err", true) } }, { pendingInfo = null; pendingText = null })
}

/* ---------------- privacy & permissions ---------------- */
fun biometricAvailable(ctx: Context) = androidx.biometric.BiometricManager.from(ctx).canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK) == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS

fun promptBiometric(ctx: Context, title: String, onOk: () -> Unit, onFail: () -> Unit) {
    val act = ctx as? FragmentActivity ?: return onFail()
    val prompt = androidx.biometric.BiometricPrompt(act, ContextCompat.getMainExecutor(ctx), object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) = onOk()
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onFail()
    })
    prompt.authenticate(androidx.biometric.BiometricPrompt.PromptInfo.Builder().setTitle(title).setNegativeButtonText(strRes(ctx, "common.cancel"))
        .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK).build())
}

@Composable
fun PrivacyScreen(vm: AppViewModel, nav: Nav) {
    val ctx = LocalContext.current
    var flow by remember { mutableStateOf<String?>(null) }       // "set" | "change" | "remove"
    var notifGranted by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifGranted = it }
    val bioOk = remember { biometricAvailable(ctx) }
    Page(tr("set.privacy"), onBack = nav.back) {
        item {
            AppCard {
                Text(tr("priv.lock"), style = MaterialTheme.typography.titleMedium); Text(tr("priv.lockHint"), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!vm.hasPin) PrimaryButton(tr("priv.setPin"), Icons.Outlined.Lock) { flow = "set" } else { SoftButton(tr("priv.change")) { flow = "change" }; SoftButton(tr("priv.remove"), danger = true) { flow = "remove" } }
                }
                if (vm.hasPin) Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(tr("priv.bio")); Text(if (bioOk) tr("priv.bioHint") else tr("priv.bioNo"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(vm.biometric, { on -> if (!on) vm.setBiometric(false) else promptBiometric(ctx, strRes(ctx, "priv.bio"), { vm.setBiometric(true); vm.toast("priv.bioOn") }, { vm.toast("priv.bioFail", true) }) }, enabled = bioOk)
                }
            }
        }
        item {
            AppCard {
                Text(tr("priv.perms"), style = MaterialTheme.typography.titleMedium)
                KV(tr("priv.storage"), tr("priv.granted"))
                KV(tr("priv.notif"), if (notifGranted) tr("priv.granted") else tr("priv.notGranted"))
                if (!notifGranted && Build.VERSION.SDK_INT >= 33) SoftButton(tr("priv.reqNotif"), Icons.Outlined.Notifications) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }
        item { AppCard { Text(tr("priv.info"), style = MaterialTheme.typography.titleMedium); listOf("priv.i1", "priv.i2", "priv.i3", "priv.i4").forEach { Text("•  " + tr(it), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) } } }
    }
    when (flow) {
        "set" -> PinSheet(vm, verifyFirst = false) { flow = null }
        "change" -> PinSheet(vm, verifyFirst = true) { flow = null }
        "remove" -> VerifyPinSheet(vm, { flow = null }) { vm.removePin(); flow = null }
    }
}

@Composable
private fun VerifyPinSheet(vm: AppViewModel, onDismiss: () -> Unit, onOk: () -> Unit) {
    var entry by remember { mutableStateOf("") }; val ctx = LocalContext.current
    FormSheet(tr("priv.enterPin"), onDismiss) {
        PinPad(tr("priv.enterPin"), entry, { k ->
            entry = if (k == "del") entry.dropLast(1) else if (entry.length < 4) entry + k else entry
            if (entry.length == 4) { if (vm.checkPin(entry)) onOk() else { entry = ""; vm.toast("priv.wrong", true) } }
        })
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun PinSheet(vm: AppViewModel, verifyFirst: Boolean, onDismiss: () -> Unit) {
    var verified by remember { mutableStateOf(!verifyFirst) }
    var first by remember { mutableStateOf<String?>(null) }; var entry by remember { mutableStateOf("") }
    val title = when { !verified -> tr("priv.enterPin"); first == null -> tr("priv.newPin"); else -> tr("priv.confirmPin") }
    FormSheet(title, onDismiss) {
        PinPad(title, entry, { k ->
            entry = if (k == "del") entry.dropLast(1) else if (entry.length < 4) entry + k else entry
            if (entry.length == 4) {
                if (!verified) { if (vm.checkPin(entry)) verified = true else vm.toast("priv.wrong", true); entry = "" }
                else if (first == null) { first = entry; entry = "" }
                else if (first == entry) { vm.setPin(entry); onDismiss() } else { first = null; entry = ""; vm.toast("priv.mismatch", true) }
            }
        })
        Spacer(Modifier.height(12.dp))
    }
}
