package com.billmitra.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Professional business palette: deep navy + steel blue, cool neutral greys, muted semantic colours.
val Navy = Color(0xFF0B1F3A)
val Navy2 = Color(0xFF14325C)
val Royal = Color(0xFF1D4F91)

class Extra(val green: Color, val greenBg: Color, val red: Color, val redBg: Color, val amber: Color, val amberBg: Color, val line: Color, val surface2: Color)

val LocalExtra = staticCompositionLocalOf { lightExtra }
private val lightExtra = Extra(Color(0xFF15803D), Color(0xFFE7F3EC), Color(0xFFB42318), Color(0xFFFBEAE8), Color(0xFFB45309), Color(0xFFFBF0DE), Color(0xFFDCE2EB), Color(0xFFEEF1F6))
private val darkExtra = Extra(Color(0xFF45C487), Color(0xFF12302A), Color(0xFFF08A82), Color(0xFF3A1D1F), Color(0xFFE9B35F), Color(0xFF372B14), Color(0xFF263243), Color(0xFF1B2533))

private val lightScheme = lightColorScheme(
    primary = Royal, onPrimary = Color.White, primaryContainer = Color(0xFFDFE8F5), onPrimaryContainer = Navy,
    secondary = Navy, onSecondary = Color.White, secondaryContainer = Color(0xFFE6EBF2), onSecondaryContainer = Navy,
    background = Color(0xFFF4F6F9), onBackground = Color(0xFF111827),
    surface = Color.White, onSurface = Color(0xFF111827), surfaceVariant = Color(0xFFEDF0F5), onSurfaceVariant = Color(0xFF586274),
    outline = Color(0xFFD5DCE6), outlineVariant = Color(0xFFDDE3EC),
    error = Color(0xFFB42318), errorContainer = Color(0xFFFBEAE8),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF0F3F8), surfaceContainer = Color(0xFFEDF1F6),
    surfaceContainerHigh = Color(0xFFE8EDF3), surfaceContainerHighest = Color(0xFFE3E9F0)
)
private val darkScheme = darkColorScheme(
    primary = Color(0xFF5B8DD6), onPrimary = Color(0xFF0B1F3A), primaryContainer = Color(0xFF1E3555), onPrimaryContainer = Color(0xFFDCE7F7),
    secondary = Color(0xFFA9BEDB), onSecondary = Color(0xFF0B1F3A), secondaryContainer = Color(0xFF222E3E), onSecondaryContainer = Color(0xFFE3E9F1),
    background = Color(0xFF0D131B), onBackground = Color(0xFFE6EBF2),
    surface = Color(0xFF141C27), onSurface = Color(0xFFE6EBF2), surfaceVariant = Color(0xFF1B2533), onSurfaceVariant = Color(0xFF98A4B5),
    outline = Color(0xFF2B3748), outlineVariant = Color(0xFF263243),
    error = Color(0xFFF08A82), errorContainer = Color(0xFF3A1D1F),
    surfaceContainerLowest = Color(0xFF0D131B), surfaceContainerLow = Color(0xFF161F2B), surfaceContainer = Color(0xFF1A2431),
    surfaceContainerHigh = Color(0xFF202B3A), surfaceContainerHighest = Color(0xFF263243)
)

// Tighter corners than the Material default: reads as a business tool rather than a toy.
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp), small = RoundedCornerShape(8.dp), medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(10.dp), extraLarge = RoundedCornerShape(12.dp)
)

@Composable
fun BillmitraTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    androidx.compose.runtime.CompositionLocalProvider(LocalExtra provides if (dark) darkExtra else lightExtra) {
        MaterialTheme(
            colorScheme = if (dark) darkScheme else lightScheme,
            shapes = AppShapes,
            typography = Typography().copy(
                titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
                titleMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            ),
            content = content
        )
    }
}
