package com.billmitra.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

val PAY_METHODS = listOf("cash", "upi", "bank", "online")
val EXPENSE_CATS = listOf("rent", "electricity", "salary", "transport", "office", "other")
const val CUSTOM_CAT_PREFIX = "c:"
const val CUSTOM_CAT_MAX = 30
fun isCustomCat(k: String) = k.startsWith(CUSTOM_CAT_PREFIX)
fun customCatKey(name: String) = CUSTOM_CAT_PREFIX + name.trim()
fun isValidCat(k: String) = k in EXPENSE_CATS || (isCustomCat(k) && k.length in (CUSTOM_CAT_PREFIX.length + 1)..(CUSTOM_CAT_PREFIX.length + CUSTOM_CAT_MAX))

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val gstin: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val demo: Boolean = false
)

@Entity(
    tableName = "bills",
    foreignKeys = [ForeignKey(entity = Customer::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("customerId"), Index(value = ["no"], unique = true)]
)
data class Bill(
    @PrimaryKey val id: String,
    val no: String,
    val customerId: String,
    val date: String,              // yyyy-MM-dd
    val description: String = "",
    val amount: Long,
    val discount: Long = 0,
    val gst: Boolean = false,
    val rateBp: Long = 0,
    val intra: Boolean = true,
    val tax: Long = 0,
    val finalAmount: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val demo: Boolean = false,
    /** optional line items as JSON (see Items); empty = a plain amount-only bill */
    @ColumnInfo(defaultValue = "''") val items: String = ""
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(entity = Bill::class, parentColumns = ["id"], childColumns = ["billId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("billId"), Index("customerId")]
)
data class Payment(
    @PrimaryKey val id: String,
    val billId: String,
    val customerId: String,
    val date: String,
    val method: String,            // cash | upi | bank | online
    val amount: Long,
    val ref: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val demo: Boolean = false
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey val id: String,
    val category: String,
    val amount: Long,
    val date: String,
    val method: String,            // cash | online
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val demo: Boolean = false
)
