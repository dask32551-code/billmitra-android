package com.billmitra.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File

object Csv {
    private val NUM = Regex("^-?\\d+(\\.\\d+)?$")
    private fun cell(v: Any?): String {
        var s = v?.toString() ?: ""
        if (v is String && s.isNotEmpty() && s[0] in "=+-@\t\r" && !NUM.matches(s)) s = "'$s"          // block spreadsheet formula injection
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }
    fun build(rows: List<List<Any?>>): String = "﻿" + rows.joinToString("\r\n") { r -> r.joinToString(",") { cell(it) } }
}

object Share {
    /** Writes [bytes] into the app cache and opens the system share sheet. */
    fun file(ctx: Context, name: String, mime: String, bytes: ByteArray, title: String) {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val f = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_")).also { it.writeBytes(bytes) }
        val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun text(ctx: Context, title: String, body: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Minimal A4 PDF writer for bills and reports (uses the system font, so Devanagari renders). */
class SimplePdf {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvasY = 0f
    private var pageNo = 0
    private val w = 595; private val h = 842; private val m = 42f
    private val footerReserve = 22f

    /** Small text at the bottom-left of every page; the page number goes bottom-right. Empty = no footer. */
    var footerText: String = ""

    private val ink = 0xFF1F2937.toInt()
    private val navy = 0xFF0F2A4A.toInt()
    private val grey = 0xFF6B7280.toInt()
    private val hair = 0xFFE5E7EB.toInt()
    private val band = 0xFFF3F4F6.toInt()

    private val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = ink }
    private val bold = TextPaint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
    private val title = TextPaint(bold).apply { textSize = 19f; color = navy }
    private val muted = TextPaint(normal).apply { color = grey; textSize = 9.5f }
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; style = Paint.Style.FILL }
    private fun stroke(c: Int, wd: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; strokeWidth = wd; style = Paint.Style.STROKE }

    private fun drawFooter() {
        if (footerText.isEmpty()) return
        val c = page!!.canvas
        val y = h - 20f
        c.drawLine(m, y - 12f, w - m, y - 12f, stroke(hair, 0.8f))
        c.drawText(footerText, m, y, muted)
        val pg = "Page $pageNo"
        c.drawText(pg, w - m - muted.measureText(pg), y, muted)
    }
    private fun ensure(space: Float) {
        if (page == null || canvasY + space > h - m - footerReserve) {
            page?.let { drawFooter(); doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            canvasY = m
        }
    }
    private fun paint(b: Boolean, big: Boolean, mut: Boolean) = when { big -> title; b -> bold; mut -> muted; else -> normal }

    fun line(text: String, boldText: Boolean = false, big: Boolean = false, mutedText: Boolean = false) {
        val p = paint(boldText, big, mutedText)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, p, (w - 2 * m).toInt()).build()
        ensure(layout.height + 4f)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        canvasY += layout.height + 4f
    }
    /** Letterhead: business name on the left, report title under it, period on the right, then a navy rule. */
    fun header(name: String, subtitle: String, right: String) {
        ensure(60f)
        val c = page!!.canvas
        c.drawText(name, m, canvasY + 16f, title)
        c.drawText(subtitle, m, canvasY + 33f, muted)
        c.drawText(right, w - m - bold.measureText(right), canvasY + 33f, bold)
        canvasY += 42f
        c.drawLine(m, canvasY, w - m, canvasY, stroke(navy, 2f))
        canvasY += 16f
    }
    /** left label (wraps if long), right-aligned value */
    fun row(left: String, right: String, boldText: Boolean = false) {
        val p = paint(boldText, false, false)
        val rightW = p.measureText(right)
        val leftW = (w - 2 * m - rightW - 12f).toInt().coerceAtLeast(60)
        val layout = StaticLayout.Builder.obtain(left, 0, left.length, p, leftW).build()
        val rowH = maxOf(layout.height.toFloat(), 14f) + 5f
        ensure(rowH)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        c.drawText(right, w - m - rightW, canvasY + 11.5f, p)
        canvasY += rowH
    }
    /** Section heading: small navy caps with a hairline underneath. */
    fun heading(text: String) {
        ensure(34f); space(10f)
        val c = page!!.canvas
        val hp = TextPaint(bold).apply { textSize = 10f; color = navy; letterSpacing = 0.06f }
        c.drawText(text.uppercase(), m, canvasY + 10f, hp)
        c.drawLine(m, canvasY + 16f, w - m, canvasY + 16f, stroke(navy, 0.9f))
        canvasY += 22f
    }
    /** Summary cards side by side: small label on top, amount below, thin coloured top edge. */
    fun bigBoxes(items: List<Triple<String, String, Int>>) {
        val gap = 10f; val bw = (w - 2 * m - gap * (items.size - 1)) / items.size; val bh = 56f
        ensure(bh + 8f)
        val c = page!!.canvas
        items.forEachIndexed { i, (label, value, color) ->
            val x = m + i * (bw + gap)
            c.drawRect(x, canvasY, x + bw, canvasY + bh, fill(0xFFFFFFFF.toInt()))
            c.drawRect(x, canvasY, x + bw, canvasY + bh, stroke(hair, 1f))
            c.drawRect(x, canvasY, x + bw, canvasY + 3f, fill(color))
            val lp = TextPaint(muted).apply { textSize = 9f }
            c.drawText(label, x + 12f, canvasY + 21f, lp)
            c.drawText(value, x + 12f, canvasY + 43f, TextPaint(bold).apply { textSize = 16f; this.color = ink })
        }
        canvasY += bh + 6f
    }
    /**
     * Table row: first column left-aligned, the rest right-aligned. [weights] are relative column widths.
     * [header] = navy column-title row with white text; [shade] = light highlighted row (e.g. a result line);
     * [boldText] without either gets a thin line above (a total).
     */
    fun cols(cells: List<String>, weights: List<Float>, boldText: Boolean = false, shade: Boolean = false, header: Boolean = false) {
        val base = paint(boldText || header, false, false)
        val p = if (header) TextPaint(base).apply { color = 0xFFFFFFFF.toInt(); textSize = 9.5f } else base
        val total = w - 2 * m; val sum = weights.sum(); val rh = 23f
        ensure(rh)
        val c = page!!.canvas
        if (header) c.drawRect(m, canvasY, w - m, canvasY + rh, fill(navy))
        else if (shade) c.drawRect(m, canvasY, w - m, canvasY + rh, fill(band))
        var x = m
        cells.forEachIndexed { i, t ->
            val cw = total * weights[i] / sum
            val baseY = canvasY + 15f
            if (i == 0) c.drawText(t, x + 8f, baseY, p) else c.drawText(t, x + cw - 8f - p.measureText(t), baseY, p)
            x += cw
        }
        if (!header && !shade) c.drawLine(m, canvasY + rh, w - m, canvasY + rh, stroke(hair, 0.8f))
        if (!header && !shade && boldText) c.drawLine(m, canvasY, w - m, canvasY, stroke(navy, 0.8f))
        canvasY += rh
    }
    fun rule() { ensure(12f); val c = page!!.canvas; c.drawLine(m, canvasY + 5f, w - m, canvasY + 5f, stroke(hair, 1f)); canvasY += 12f }
    fun space(px: Float = 8f) { canvasY += px }

    fun toBytes(): ByteArray {
        page?.let { drawFooter(); doc.finishPage(it) }
        val out = java.io.ByteArrayOutputStream()
        doc.writeTo(out); doc.close()
        return out.toByteArray()
    }
}
