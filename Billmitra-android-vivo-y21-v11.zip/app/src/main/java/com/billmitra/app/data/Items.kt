package com.billmitra.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode

/** One line of a bill: name, quantity (decimal text, e.g. "2.5") and rate per unit in minor units (paise). */
data class BillItem(val name: String, val qty: String, val rate: Long) {
    fun total(): Long = Items.lineTotal(qty, rate) ?: 0L
    fun qtyLabel(): String = try { BigDecimal(qty).stripTrailingZeros().toPlainString() } catch (e: Exception) { qty }
}

object Items {
    private val QTY = Regex("^(\\d{1,7}(\\.\\d{1,3})?|\\.\\d{1,3})$")

    /** quantity x rate rounded to whole paise, or null when the quantity is not a valid number above zero. */
    fun lineTotal(qty: String, rate: Long): Long? {
        val q = qty.trim()
        if (!QTY.matches(q) || rate < 0) return null
        val v = BigDecimal(q)
        if (v.signum() <= 0) return null
        return v.multiply(BigDecimal.valueOf(rate)).setScale(0, RoundingMode.HALF_UP).toLong()
    }

    fun parse(json: String): List<BillItem> {
        if (json.isBlank()) return emptyList()
        return try {
            val a = JSONArray(json)
            (0 until a.length()).mapNotNull { i ->
                val o = a.optJSONObject(i) ?: return@mapNotNull null
                val name = o.optString("n").trim(); val q = o.optString("q").trim(); val r = o.optLong("r", -1)
                if (name.isEmpty() || r < 0 || lineTotal(q, r) == null) null else BillItem(name.take(80), q, r)
            }
        } catch (e: Exception) { emptyList() }
    }

    fun toJson(list: List<BillItem>): String =
        if (list.isEmpty()) "" else JSONArray().also { a -> list.forEach { a.put(JSONObject().put("n", it.name).put("q", it.qty).put("r", it.rate)) } }.toString()
}
