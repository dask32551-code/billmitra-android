@file:OptIn(ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billmitra.app.data.*
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

@Composable
fun DashboardScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState()
    val expenses by vm.expenses.collectAsState(); val customers by vm.customers.collectAsState()
    var period by rememberSaveable { mutableStateOf("all") }
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    val today = LocalDate.now()
    val (from, to) = when (period) {
        "today" -> today.toString() to today.toString()
        "week" -> today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString() to today.toString()
        "month" -> today.withDayOfMonth(1).toString() to today.toString()
        else -> null to null
    }
    val t = remember(bills, payments, expenses, period) { totals(bills, payments, expenses, from, to) }
    val ex = LocalExtra.current
    val hasDemo = customers.any { it.demo } || bills.any { it.demo } || expenses.any { it.demo }
    var askRemove by remember { mutableStateOf(false) }
    val unknown = tr("common.unknown")

    Page(vm.profile.name.ifBlank { tr("app.name") }) {
        if (hasDemo) item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Outlined.Info, null, tint = Royal)
                Text(tr("demo.banner"), Modifier.weight(1f), fontSize = 13.sp)
                TextButton({ askRemove = true }) { Text(tr("demo.remove"), fontSize = 12.sp) }
            }
        }
        if (customers.isEmpty() && bills.isEmpty() && payments.isEmpty() && expenses.isEmpty() && vm.profile.name.isBlank()) item {
            AppCard {
                Text(tr("welcome.title"), fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(tr("welcome.text"), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                PrimaryButton(tr("welcome.profile")) { nav.go("settings/profile") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("all", "today", "week", "month").forEach { p -> FilterChip(period == p, { period = p }, label = { Text(tr("period.$p")) }, shape = RoundedCornerShape(99.dp)) }
            }
        }
        item {
            NavyCard {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.TrendingUp, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(tr("dash.sales"), color = Color.White.copy(alpha = .85f)) }
                Spacer(Modifier.height(4.dp))
                AnimatedMoney(t.sales, Color.White, 32)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(trf("dash.billsCount", t.bills.toString()), color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                    Text(tr("dash.collected") + ": " + Money.format(t.received), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(Modifier.weight(1f), Icons.Outlined.Warning, ex.redBg, ex.red, tr("dash.dues"), ledger.outstanding, tr("dash.duesHint"))
                    StatCard(Modifier.weight(1f), Icons.Outlined.Payments, ex.greenBg, ex.green, tr("dash.cash"), t.cash)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(Modifier.weight(1f), Icons.Outlined.PhoneAndroid, MaterialTheme.colorScheme.surfaceVariant, Royal, tr("dash.online"), t.online)
                    StatCard(Modifier.weight(1f), Icons.Outlined.RemoveCircleOutline, ex.amberBg, ex.amber, tr("dash.expenses"), t.expenses)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction(Modifier.weight(1f), Icons.Outlined.Description, tr("qa.bill")) { nav.openBillForm() }
                QuickAction(Modifier.weight(1f), Icons.Outlined.Payments, tr("qa.payment")) { nav.openPaymentForm() }
                QuickAction(Modifier.weight(1f), Icons.Outlined.PersonAdd, tr("qa.customer")) { nav.openCustomerForm() }
                QuickAction(Modifier.weight(1f), Icons.Outlined.AccountBalanceWallet, tr("qa.expense")) { nav.openExpenseForm() }
            }
        }
        item {
            AppCard {
                val days = (6 downTo 0).map { today.minusDays(it.toLong()).toString() }
                val sales = days.map { d -> bills.filter { it.date == d }.sumOf { it.finalAmount } }
                val coll = days.map { d -> payments.filter { it.date == d }.sumOf { it.amount } }
                SectionTitle(tr("dash.last7")) { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Legend(Royal, tr("dash.sales")); Legend(ex.green, tr("dash.collected")) } }
                Spacer(Modifier.height(8.dp))
                BarChart(sales, coll, days.map { it.takeLast(2) }, Royal, ex.green, ex.line)
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Donut(t.cash, t.online, ex.green, Royal, ex.line)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(tr("dash.mix"), style = MaterialTheme.typography.titleMedium)
                        Legend(ex.green, tr("method.cash") + "  " + Money.format(t.cash))
                        Legend(Royal, tr("dash.online") + "  " + Money.format(t.online))
                    }
                }
            }
        }
        item {
            AppCard {
                SectionTitle(tr("dash.recentBills")) { TextButton({ nav.tab("bills") }) { Text(tr("common.viewAll")) } }
                val recent = bills.take(5)
                if (recent.isEmpty()) EmptyState(Icons.Outlined.Inbox, tr("bills.empty"), tr("bills.emptySub"))
                recent.forEach { BillRow(it, ledger, unknown) { nav.bill(it.id) } }
            }
        }
        item {
            AppCard {
                SectionTitle(tr("dash.recentTx")) { TextButton({ nav.go("settings/payments") }) { Text(tr("common.viewAll")) } }
                data class Tx(val date: String, val at: Long, val title: String, val sub: String, val amount: Long, val inflow: Boolean, val billId: String?, val method: String)
                val tx = (payments.map { p -> val b = ledger.bills.firstOrNull { it.id == p.billId }; Tx(p.date, p.createdAt, ledger.customerName(p.customerId, unknown), strRes(androidx.compose.ui.platform.LocalContext.current, "method." + p.method) + (b?.let { " · " + it.no } ?: ""), p.amount, true, p.billId, p.method) } +
                    expenses.map { e -> Tx(e.date, e.createdAt, catName(e.category), strRes(androidx.compose.ui.platform.LocalContext.current, if (e.method == "cash") "method.cash" else "exp.online"), e.amount, false, null, e.method) })
                    .sortedWith(compareByDescending<Tx> { it.date }.thenByDescending { it.at }).take(6)
                if (tx.isEmpty()) EmptyState(Icons.Outlined.Inbox, tr("tx.empty"))
                tx.forEach { x ->
                    ListRow(if (x.inflow) (if (x.method == "cash") Icons.Outlined.Payments else Icons.Outlined.PhoneAndroid) else Icons.Outlined.RemoveCircleOutline,
                        if (x.inflow) ex.greenBg else ex.redBg, if (x.inflow) ex.green else ex.red, x.title, fmtDate(x.date) + " · " + x.sub,
                        trailing = { Text((if (x.inflow) "+" else "−") + Money.format(x.amount), color = if (x.inflow) ex.green else ex.red, fontWeight = FontWeight.Bold) },
                        onClick = x.billId?.let { id -> { nav.bill(id) } })
                }
            }
        }
    }
    if (askRemove) ConfirmDialog(tr("demo.removeTitle"), tr("demo.removeMsg"), tr("demo.remove"), { vm.removeDemo() }, { askRemove = false })
}

@Composable
private fun StatCard(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, fg: Color, label: String, value: Long, hint: String? = null) {
    AppCard(modifier) {
        IconBadge(icon, bg, fg); Spacer(Modifier.height(8.dp))
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        AnimatedMoney(value, size = 19)
        if (hint != null) Text(hint, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun QuickAction(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Royal), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color)); Spacer(Modifier.width(5.dp)); Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
private fun BarChart(a: List<Long>, b: List<Long>, labels: List<String>, ca: Color, cb: Color, grid: Color) {
    val max = maxOf(1L, a.maxOrNull() ?: 0, b.maxOrNull() ?: 0).toFloat()
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    Column {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val groupW = size.width / a.size
            drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), 2f)
            drawLine(grid, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1f)
            a.indices.forEach { i ->
                val bw = groupW * 0.28f
                val x0 = i * groupW + groupW / 2 - bw - 2f
                val ha = size.height * (a[i] / max); val hb = size.height * (b[i] / max)
                drawRoundRect(ca, Offset(x0, size.height - ha), Size(bw, ha), CornerRadius(5f))
                drawRoundRect(cb, Offset(x0 + bw + 4f, size.height - hb), Size(bw, hb), CornerRadius(5f))
            }
        }
        Row(Modifier.fillMaxWidth()) { labels.forEach { Text(it, Modifier.weight(1f), fontSize = 10.sp, color = labelColor, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
    }
}

@Composable
private fun Donut(cash: Long, online: Long, c1: Color, c2: Color, bg: Color) {
    val total = (cash + online).toFloat()
    Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val st = Stroke(width = 26f, cap = StrokeCap.Butt)
            drawArc(bg, 0f, 360f, false, style = st)
            if (total > 0) {
                val s1 = 360f * cash / total
                drawArc(c1, -90f, s1, false, style = st)
                drawArc(c2, -90f + s1, 360f - s1, false, style = st)
            }
        }
        Text(if (total > 0) "${Math.round(online * 100f / total)}%" else "–", fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BillRow(b: Bill, ledger: Ledger, unknown: String, onClick: () -> Unit) {
    ListRow(Icons.Outlined.Description, MaterialTheme.colorScheme.surfaceVariant, Royal, ledger.customerName(b.customerId, unknown), b.no + " · " + fmtDate(b.date),
        trailing = { Text(Money.format(b.finalAmount), fontWeight = FontWeight.Bold); StatusChip(ledger.status(b)) }, onClick = onClick)
}
