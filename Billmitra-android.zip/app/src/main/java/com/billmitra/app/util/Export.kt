package com.billmitra.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File

object Csv {
    private fun cell(v: Any?): String {
        var s = v?.toString() ?: ""
        if (v is String && s.isNotEmpty() && s[0] in "=+-@\t\r") s = "'$s"          // block spreadsheet formula injection
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }
    fun build(rows: List<List<Any?>>): String = "﻿" + rows.joinToString("\r\n") { r -> r.joinToString(",") { cell(it) } }
}

object Share {
    /** Writes [bytes] into the app cache and opens the system share sheet. */
    fun file(ctx: Context, name: String, mime: String, bytes: ByteArray, title: String) {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val f = File(dir, name).also { it.writeBytes(bytes) }
        val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun text(ctx: Context, title: String, body: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Minimal A4 PDF writer for bills and reports (uses the system font, so Devanagari renders). */
class SimplePdf {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvasY = 0f
    private var pageNo = 0
    private val w = 595; private val h = 842; private val m = 40f
    private val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = 0xFF111111.toInt() }
    private val bold = TextPaint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
    private val title = TextPaint(bold).apply { textSize = 20f; color = 0xFF0A1F44.toInt() }
    private val muted = TextPaint(normal).apply { color = 0xFF667788.toInt(); textSize = 10f }

    private fun ensure(space: Float) {
        if (page == null || canvasY + space > h - m) {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            canvasY = m
        }
    }
    private fun paint(b: Boolean, big: Boolean, mut: Boolean) = when { big -> title; b -> bold; mut -> muted; else -> normal }

    fun line(text: String, boldText: Boolean = false, big: Boolean = false, mutedText: Boolean = false) {
        val p = paint(boldText, big, mutedText)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, p, (w - 2 * m).toInt()).build()
        ensure(layout.height + 4f)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        canvasY += layout.height + 4f
    }
    /** left label (wraps if long), right-aligned value */
    fun row(left: String, right: String, boldText: Boolean = false) {
        val p = paint(boldText, false, false)
        val rightW = p.measureText(right)
        val leftW = (w - 2 * m - rightW - 12f).toInt().coerceAtLeast(60)
        val layout = StaticLayout.Builder.obtain(left, 0, left.length, p, leftW).build()
        val rowH = maxOf(layout.height.toFloat(), 14f) + 4f
        ensure(rowH)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        c.drawText(right, w - m - rightW, canvasY + 12f, p)
        canvasY += rowH
    }
    fun rule() { ensure(10f); val c = page!!.canvas; val pt = Paint().apply { color = 0xFF0A1F44.toInt(); strokeWidth = 1.5f }; c.drawLine(m, canvasY + 4f, w - m, canvasY + 4f, pt); canvasY += 10f }
    fun space(px: Float = 8f) { canvasY += px }

    fun toBytes(): ByteArray {
        page?.let { doc.finishPage(it) }
        val out = java.io.ByteArrayOutputStream()
        doc.writeTo(out); doc.close()
        return out.toByteArray()
    }
}
