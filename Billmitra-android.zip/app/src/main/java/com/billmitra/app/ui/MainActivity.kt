@file:OptIn(ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.billmitra.app.data.Money
import java.time.LocalDate

/** Navigation + form launchers handed to every screen. */
class Nav(
    val back: () -> Unit, val go: (String) -> Unit, val tab: (String) -> Unit,
    val bill: (String) -> Unit, val customer: (String) -> Unit,
    private val showBillForm: (String?, String?) -> Unit,
    private val showPaymentForm: (String?, String?) -> Unit,
    private val showCustomerForm: (String?) -> Unit,
    private val showExpenseForm: (String?) -> Unit
) {
    fun openBillForm(editId: String? = null, presetCustomer: String? = null) = showBillForm(editId, presetCustomer)
    fun openPaymentForm(billId: String? = null, paymentId: String? = null) = showPaymentForm(billId, paymentId)
    fun openCustomerForm(editId: String? = null) = showCustomerForm(editId)
    fun openExpenseForm(editId: String? = null) = showExpenseForm(editId)
}

class MainActivity : AppCompatActivity() {
    private val vm: AppViewModel by viewModels()
    private var leftAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && vm.reminders.enabled)
            registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { BillmitraTheme(vm.theme) { Root(vm) } }
    }

    // lock again if the app was away for more than a minute
    override fun onStop() { super.onStop(); leftAt = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        if (vm.hasPin && leftAt > 0 && System.currentTimeMillis() - leftAt > 60_000) vm.locked = true
    }
}

private data class Tab(val route: String, val icon: ImageVector, val labelKey: String)
private val TABS = listOf(Tab("dashboard", Icons.Outlined.Dashboard, "nav.dashboard"), Tab("bills", Icons.Outlined.Description, "nav.bills"),
    Tab("customers", Icons.Outlined.People, "nav.customers"), Tab("expenses", Icons.Outlined.AccountBalanceWallet, "nav.expenses"), Tab("settings", Icons.Outlined.Settings, "nav.settings"))

@Composable
private fun Root(vm: AppViewModel) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    var success by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.toasts.collect { m -> snack.currentSnackbarData?.dismiss(); snack.showSnackbar(strRes(ctx, m.key, *m.args.toTypedArray())) } }
    LaunchedEffect(Unit) { vm.successes.collect { success = it } }

    Box(Modifier.fillMaxSize()) {
        if (!vm.loaded) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (vm.locked) LockScreen(vm)
        else {
            MainScaffold(vm, snack)
            ReminderOnOpen(vm)
        }
        SuccessOverlay(success) { success = null }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 88.dp))
    }
}

@Composable
private fun MainScaffold(vm: AppViewModel, snack: SnackbarHostState) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "dashboard"
    val activeTab = when { route.startsWith("bill") -> "bills"; route.startsWith("customer") -> "customers"; else -> route.substringBefore('/') }

    // form sheets live at the root so they work from any screen
    var billForm by remember { mutableStateOf<Pair<String?, String?>?>(null) }
    var payForm by remember { mutableStateOf<Pair<String?, String?>?>(null) }
    var custForm by remember { mutableStateOf<String?>(null) }; var custOpen by remember { mutableStateOf(false) }
    var expForm by remember { mutableStateOf<String?>(null) }; var expOpen by remember { mutableStateOf(false) }

    val n = remember(nav) {
        Nav(back = { nav.popBackStack() }, go = { nav.navigate(it) }, tab = { r -> nav.navigate(r) { popUpTo("dashboard") { saveState = true }; launchSingleTop = true; restoreState = true } },
            bill = { nav.navigate("bill/$it") }, customer = { nav.navigate("customer/$it") },
            showBillForm = { e, c -> billForm = e to c }, showPaymentForm = { b, p -> payForm = b to p },
            showCustomerForm = { custForm = it; custOpen = true }, showExpenseForm = { expForm = it; expOpen = true })
    }
    Scaffold(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background, bottomBar = {
        NavigationBar(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface) {
            TABS.forEach { t ->
                NavigationBarItem(selected = activeTab == t.route, onClick = { n.tab(t.route) }, icon = { Icon(t.icon, null) },
                    label = { Text(tr(t.labelKey), maxLines = 1, style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Royal, selectedTextColor = Royal, indicatorColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant))
            }
        }
    }) { pad ->
        val ms = if (animationsEnabled(LocalContext.current)) 240 else 0
        NavHost(nav, "dashboard", Modifier.padding(pad).consumeWindowInsets(pad),
            enterTransition = { fadeIn(tween(ms)) + slideInHorizontally(tween(ms)) { it / 10 } }, exitTransition = { fadeOut(tween(ms / 2)) },
            popEnterTransition = { fadeIn(tween(ms)) + slideInHorizontally(tween(ms)) { -it / 10 } }, popExitTransition = { fadeOut(tween(ms / 2)) + slideOutHorizontally(tween(ms)) { it / 10 } }) {
            composable("dashboard") { DashboardScreen(vm, n) }
            composable("bills") { BillsScreen(vm, n) }
            composable("bill/{id}") { BillDetailScreen(vm, n, it.arguments?.getString("id") ?: "") }
            composable("customers") { CustomersScreen(vm, n) }
            composable("customer/{id}") { CustomerDetailScreen(vm, n, it.arguments?.getString("id") ?: "") }
            composable("expenses") { ExpensesScreen(vm, n) }
            composable("settings") { SettingsScreen(vm, n) }
            composable("settings/payments") { PaymentHistoryScreen(vm, n) }
            composable("settings/reports") { ReportsScreen(vm, n) }
            composable("settings/profile") { ProfileScreen(vm, n) }
            composable("settings/reminders") { RemindersScreen(vm, n) }
            composable("settings/language") { LanguageScreen(n) }
            composable("settings/appearance") { AppearanceScreen(vm, n) }
            composable("settings/privacy") { PrivacyScreen(vm, n) }
            composable("settings/backup") { BackupScreen(vm, n) }
            composable("settings/export") { ExportScreen(vm, n) }
            composable("settings/about") { AboutScreen(n) }
        }
    }
    billForm?.let { (e, c) -> BillForm(vm, e, c) { billForm = null } }
    payForm?.let { (b, p) -> PaymentForm(vm, b, p) { payForm = null } }
    if (custOpen) CustomerForm(vm, custForm, { custOpen = false }) {}
    if (expOpen) ExpenseForm(vm, expForm) { expOpen = false }
}

@Composable
private fun LockScreen(vm: AppViewModel) {
    var entry by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { if (vm.biometric) promptBiometric(ctx, strRes(ctx, "priv.bio"), { vm.locked = false }, {}) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Outlined.Lock, null, Modifier.size(40.dp), tint = Royal)
        Spacer(Modifier.height(8.dp)); Text(tr("app.name"), style = androidx.compose.material3.MaterialTheme.typography.titleLarge); Spacer(Modifier.height(18.dp))
        PinPad(tr("priv.enterPin"), entry, { k ->
            entry = if (k == "del") entry.dropLast(1) else if (entry.length < 4) entry + k else entry
            if (entry.length == 4) { if (vm.checkPin(entry)) vm.locked = false else { entry = ""; vm.toast("priv.wrong", true) } }
        }) { if (vm.biometric) TextButton({ promptBiometric(ctx, strRes(ctx, "priv.bio"), { vm.locked = false }, {}) }) { Icon(Icons.Outlined.Fingerprint, null); Spacer(Modifier.width(6.dp)); Text(tr("priv.useBio")) } }
    }
}

/** Once a day, tell the user how many customers have overdue payments. */
@Composable
private fun ReminderOnOpen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    LaunchedEffect(bills.size, payments.size) {
        val cfg = vm.reminders; val today = LocalDate.now().toString()
        if (!cfg.enabled || vm.prefs.lastReminderDay == today || bills.isEmpty()) return@LaunchedEffect
        val od = overdueList(bills, Ledger(bills, payments, customers), cfg.afterDays)
        if (od.isEmpty()) return@LaunchedEffect
        vm.prefs.lastReminderDay = today
        val body = strRes(ctx, "rem.toast", od.size.toString(), Money.format(od.sumOf { it.due }))
        vm.toasts.emit(Msg("rem.toast", listOf(od.size.toString(), Money.format(od.sumOf { it.due }))))
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("reminders", strRes(ctx, "set.reminders"), NotificationManager.IMPORTANCE_DEFAULT))
            val n = NotificationCompat.Builder(ctx, "reminders").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(strRes(ctx, "app.name")).setContentText(body).setAutoCancel(true).build()
            runCatching { NotificationManagerCompat.from(ctx).notify(1, n) }
        }
    }
}
