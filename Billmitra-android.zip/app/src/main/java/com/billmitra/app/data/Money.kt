package com.billmitra.app.data

import java.time.LocalDate

/** All money is stored as Long minor units (paise). No floating point is ever used for amounts. */
object Money {
    const val MAX: Long = 100_000_000_000L

    /** "1,234.50" -> 123450. Returns null for anything invalid (negative, >2 decimals, junk, too large). */
    fun parse(input: String): Long? {
        val s = input.trim().replace("₹", "").replace(",", "").replace(" ", "")
        if (!Regex("^\\d+(\\.\\d{0,2})?$").matches(s)) return null
        val parts = s.split('.')
        val rupees = parts[0].toLongOrNull() ?: return null
        val paise = ((parts.getOrNull(1) ?: "") + "00").take(2).toLong()
        if (rupees > MAX / 100) return null
        val minor = rupees * 100 + paise
        return if (minor in 0..MAX) minor else null
    }

    /** 123456789 -> "₹12,34,567.89" (Indian digit grouping). */
    fun format(minor: Long): String {
        val neg = minor < 0
        val abs = Math.abs(minor)
        val rupees = (abs / 100).toString()
        val paise = (abs % 100).toInt()
        val grouped = if (rupees.length <= 3) rupees else {
            val head = rupees.dropLast(3)
            val tail = rupees.takeLast(3)
            head.reversed().chunked(2).joinToString(",").reversed() + "," + tail
        }
        val p = if (paise == 0) "" else "." + paise.toString().padStart(2, '0')
        return (if (neg) "-" else "") + "₹" + grouped + p
    }

    /** Editable plain string: 123450 -> "1234.5" style without trailing zeros problems -> "1234.50". */
    fun toInput(minor: Long): String {
        val r = minor / 100
        val p = (minor % 100).toInt()
        return if (p == 0) r.toString() else "$r." + p.toString().padStart(2, '0')
    }
}

data class BillCalc(val amount: Long, val discount: Long, val base: Long, val tax: Long, val cgst: Long, val sgst: Long, val igst: Long, val final: Long)

fun calcBill(amount: Long, discount: Long, gst: Boolean, rateBp: Long, intra: Boolean): BillCalc {
    val base = amount - discount
    var tax = 0L; var cgst = 0L; var sgst = 0L; var igst = 0L
    if (gst && rateBp > 0 && base > 0) {
        tax = (base * rateBp + 5000) / 10000          // round half up, integer only
        if (intra) { cgst = tax / 2; sgst = tax - cgst } else igst = tax
    }
    return BillCalc(amount, discount, base, tax, cgst, sgst, igst, base + tax)
}

enum class PayStatus { PAID, PARTIAL, UNPAID }

fun payStatus(final: Long, paid: Long): PayStatus = when {
    final > 0 && paid >= final -> PayStatus.PAID
    paid > 0 -> PayStatus.PARTIAL
    else -> PayStatus.UNPAID
}

fun today(): String = LocalDate.now().toString()
fun isValidDate(s: String): Boolean = try { LocalDate.parse(s); true } catch (e: Exception) { false }
