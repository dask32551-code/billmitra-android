package com.billmitra.app.data

import org.json.JSONArray
import org.json.JSONObject

/** JSON backup, format-compatible with the Billmitra web app. */
object Backup {
    class Parsed(
        val customers: List<Customer>, val bills: List<Bill>, val payments: List<Payment>, val expenses: List<Expense>,
        val profile: Profile?, val reminders: ReminderCfg?, val billCounter: Long
    )

    /** Thrown with a translation key suffix (bk.err.<key>). */
    class BackupError(val key: String) : Exception(key)

    fun toJson(c: List<Customer>, b: List<Bill>, p: List<Payment>, e: List<Expense>, prefs: Prefs): String {
        val root = JSONObject().put("app", "Billmitra").put("version", 1).put("exportedAt", java.time.Instant.now().toString())
        val data = JSONObject()
        data.put("customers", JSONArray().also { a -> c.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("phone", it.phone).put("address", it.address).put("gstin", it.gstin).put("createdAt", it.createdAt).put("demo", it.demo)) } })
        data.put("bills", JSONArray().also { a -> b.forEach {
            a.put(JSONObject().put("id", it.id).put("no", it.no).put("customerId", it.customerId).put("date", it.date).put("description", it.description)
                .put("amount", it.amount).put("discount", it.discount).put("taxMode", if (it.gst) "gst" else "none").put("rateBp", it.rateBp)
                .put("intra", it.intra).put("tax", it.tax).put("final", it.finalAmount).put("createdAt", it.createdAt).put("demo", it.demo)
                .also { j -> if (it.items.isNotBlank()) j.put("items", JSONArray(it.items)) }) } })
        data.put("payments", JSONArray().also { a -> p.forEach { a.put(JSONObject().put("id", it.id).put("billId", it.billId).put("customerId", it.customerId).put("date", it.date).put("method", it.method).put("amount", it.amount).put("ref", it.ref).put("notes", it.notes).put("createdAt", it.createdAt).put("demo", it.demo)) } })
        data.put("expenses", JSONArray().also { a -> e.forEach { a.put(JSONObject().put("id", it.id).put("category", it.category).put("amount", it.amount).put("date", it.date).put("method", it.method).put("notes", it.notes).put("createdAt", it.createdAt).put("demo", it.demo)) } })
        root.put("data", data)
        val pr = prefs.profile(); val rm = prefs.reminders()
        root.put("meta", JSONObject()
            .put("profile", JSONObject().put("name", pr.name).put("owner", pr.owner).put("phone", pr.phone).put("email", pr.email).put("address", pr.address)
                .put("gstin", pr.gstin).put("upi", pr.upi).put("prefix", pr.prefix).put("taxMode", if (pr.gst) "gst" else "none").put("rateBp", pr.rateBp).put("footer", pr.footer))
            .put("billCounter", prefs.billCounter)
            .put("reminders", JSONObject().put("enabled", rm.enabled).put("afterDays", rm.afterDays)))
        return root.toString()
    }

    /** Fully validates before anything is written, so a bad file never changes existing data. */
    fun parse(text: String): Parsed {
        val root = try { JSONObject(text) } catch (e: Exception) { throw BackupError("notBackup") }
        if (root.optString("app") != "Billmitra") throw BackupError("notBackup")
        if (root.optInt("version", 0) !in 1..1) throw BackupError("badVersion")
        val data = root.optJSONObject("data") ?: throw BackupError("corrupt")
        try {
            val seen = HashSet<String>()
            fun str(o: JSONObject, k: String, required: Boolean = false): String {
                val v = if (o.isNull(k)) "" else o.get(k)
                if (v !is String) throw BackupError("corrupt")
                if (required && v.isEmpty()) throw BackupError("corrupt")
                if (v.length > 5000) throw BackupError("corrupt")
                return v
            }
            fun minor(o: JSONObject, k: String, allowZero: Boolean): Long {
                val v = o.opt(k) ?: if (allowZero) return 0L else throw BackupError("corrupt")
                if (v !is Int && v !is Long) throw BackupError("corrupt")
                val l = (v as Number).toLong()
                if (l < 0 || l > Money.MAX * 2 || (!allowZero && l == 0L)) throw BackupError("corrupt")
                return l
            }
            fun uniq(prefix: String, id: String) { if (!seen.add(prefix + id)) throw BackupError("corrupt") }
            val customers = (0 until data.getJSONArray("customers").length()).map { i ->
                val o = data.getJSONArray("customers").getJSONObject(i)
                val id = str(o, "id", true); uniq("c", id)
                Customer(id, str(o, "name", true), str(o, "phone"), str(o, "address"), str(o, "gstin"), o.optLong("createdAt"), o.optBoolean("demo"),
                    Items.toJson(Items.parse(o.optJSONArray("items")?.toString() ?: "")))
            }
            val custIds = customers.map { it.id }.toSet()
            val nos = HashSet<String>()
            val bills = (0 until data.getJSONArray("bills").length()).map { i ->
                val o = data.getJSONArray("bills").getJSONObject(i)
                val id = str(o, "id", true); uniq("b", id)
                val no = str(o, "no", true); if (!nos.add(no)) throw BackupError("corrupt")
                val cid = str(o, "customerId", true); if (cid !in custIds) throw BackupError("corrupt")
                val date = str(o, "date", true); if (!isValidDate(date)) throw BackupError("corrupt")
                val gst = o.optString("taxMode") == "gst"
                val rateBp = if (gst) o.optLong("rateBp") else 0L
                if (rateBp < 0 || rateBp > 10000) throw BackupError("corrupt")
                val intra = o.optBoolean("intra", true)
                val amount = minor(o, "amount", false); val discount = minor(o, "discount", true)
                val k = calcBill(amount, discount, gst, rateBp, intra)
                if (k.base <= 0) throw BackupError("corrupt")
                // Keep the stored tax/final when they are consistent (so old backups restore exactly); otherwise recompute.
                val storedTax = if (o.has("tax")) minor(o, "tax", true) else -1L
                val storedFinal = if (o.has("final")) minor(o, "final", false) else -1L
                val keep = gst && storedTax >= 0 && storedFinal == k.base + storedTax && Math.abs(storedTax - k.tax) <= 1
                val tax = if (keep) storedTax else k.tax
                val finalAmt = if (keep) storedFinal else k.final
                Bill(id, no, cid, date, str(o, "description"), k.amount, k.discount, gst, rateBp, intra, tax, finalAmt, o.optLong("createdAt"), o.optBoolean("demo"))
            }
            val billMap = bills.associateBy { it.id }
            val paid = HashMap<String, Long>()
            val payments = (0 until data.getJSONArray("payments").length()).map { i ->
                val o = data.getJSONArray("payments").getJSONObject(i)
                val id = str(o, "id", true); uniq("p", id)
                val b = billMap[str(o, "billId", true)] ?: throw BackupError("corrupt")
                val date = str(o, "date", true); if (!isValidDate(date)) throw BackupError("corrupt")
                val method = str(o, "method", true); if (method !in PAY_METHODS) throw BackupError("corrupt")
                val amt = minor(o, "amount", false)
                val total = (paid[b.id] ?: 0L) + amt; paid[b.id] = total
                if (total > b.finalAmount) throw BackupError("overpaid")
                Payment(id, b.id, b.customerId, date, method, amt, str(o, "ref"), str(o, "notes"), o.optLong("createdAt"), o.optBoolean("demo"))
            }
            val expenses = (0 until data.getJSONArray("expenses").length()).map { i ->
                val o = data.getJSONArray("expenses").getJSONObject(i)
                val id = str(o, "id", true); uniq("e", id)
                val date = str(o, "date", true); if (!isValidDate(date)) throw BackupError("corrupt")
                val cat = str(o, "category", true); if (!isValidCat(cat)) throw BackupError("corrupt")
                val m = str(o, "method", true); if (m != "cash" && m != "online") throw BackupError("corrupt")
                Expense(id, cat, minor(o, "amount", false), date, m, str(o, "notes"), o.optLong("createdAt"), o.optBoolean("demo"))
            }
            val meta = root.optJSONObject("meta")
            val pj = meta?.optJSONObject("profile")
            val profile = pj?.let {
                Profile(it.optString("name"), it.optString("owner"), it.optString("phone"), it.optString("email"), it.optString("address"), it.optString("gstin"),
                    it.optString("upi"), it.optString("prefix", "BM-").ifEmpty { "BM-" }, it.optString("taxMode") == "gst", it.optLong("rateBp", 1800), it.optString("footer"))
            }
            val rj = meta?.optJSONObject("reminders")
            val reminders = rj?.let { ReminderCfg(it.optBoolean("enabled", true), it.optInt("afterDays", 7).coerceIn(1, 365)) }
            return Parsed(customers, bills, payments, expenses, profile, reminders, meta?.optLong("billCounter") ?: 0L)
        } catch (e: BackupError) { throw e } catch (e: Exception) { throw BackupError("corrupt") }
    }
}
