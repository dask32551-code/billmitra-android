package com.billmitra.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE") fun customers(): Flow<List<Customer>>
    @Query("SELECT * FROM bills ORDER BY date DESC, createdAt DESC") fun bills(): Flow<List<Bill>>
    @Query("SELECT * FROM payments ORDER BY date DESC, createdAt DESC") fun payments(): Flow<List<Payment>>
    @Query("SELECT * FROM expenses ORDER BY date DESC, createdAt DESC") fun expenses(): Flow<List<Expense>>

    @Query("SELECT * FROM customers") suspend fun allCustomers(): List<Customer>
    @Query("SELECT * FROM bills") suspend fun allBills(): List<Bill>
    @Query("SELECT * FROM payments") suspend fun allPayments(): List<Payment>
    @Query("SELECT * FROM expenses") suspend fun allExpenses(): List<Expense>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(c: Customer)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(b: Bill)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(p: Payment)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(e: Expense)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCustomers(l: List<Customer>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBills(l: List<Bill>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPayments(l: List<Payment>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putExpenses(l: List<Expense>)

    @Query("DELETE FROM customers WHERE id = :id") suspend fun deleteCustomer(id: String)
    @Query("DELETE FROM bills WHERE id = :id") suspend fun deleteBill(id: String)
    @Query("DELETE FROM payments WHERE id = :id") suspend fun deletePayment(id: String)
    @Query("DELETE FROM expenses WHERE id = :id") suspend fun deleteExpense(id: String)
    @Query("DELETE FROM payments") suspend fun clearPayments()
    @Query("DELETE FROM bills") suspend fun clearBills()
    @Query("DELETE FROM customers") suspend fun clearCustomers()
    @Query("DELETE FROM expenses") suspend fun clearExpenses()

    @Query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE billId = :billId AND id != :exceptId")
    suspend fun paidForBillExcept(billId: String, exceptId: String): Long
    @Query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE billId = :billId") suspend fun paidForBill(billId: String): Long
    @Query("SELECT COUNT(*) FROM bills WHERE no = :no AND id != :exceptId") suspend fun billNoUsed(no: String, exceptId: String): Int
    @Query("SELECT COUNT(*) FROM bills WHERE customerId = :cid") suspend fun billCountFor(cid: String): Int
    @Query("SELECT * FROM bills WHERE id = :id") suspend fun billById(id: String): Bill?
    @Query("UPDATE payments SET customerId = :cid WHERE billId = :billId") suspend fun moveBillPayments(billId: String, cid: String)
    @Query("SELECT * FROM payments WHERE id = :id") suspend fun paymentById(id: String): Payment?
}

@Database(entities = [Customer::class, Bill::class, Payment::class, Expense::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        fun create(ctx: Context): AppDatabase =
            Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "billmitra.db").build()
    }
}
