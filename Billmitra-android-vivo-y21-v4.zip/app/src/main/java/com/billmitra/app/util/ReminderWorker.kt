package com.billmitra.app.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.billmitra.app.BillmitraApp
import com.billmitra.app.data.Money
import com.billmitra.app.ui.MainActivity
import com.billmitra.app.ui.strRes
import java.time.LocalDate

/** Daily background check: notifies when customers have overdue payments. */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as BillmitraApp
        val cfg = app.prefs.reminders()
        val today = LocalDate.now().toString()
        if (!cfg.enabled || app.prefs.lastReminderDay == today) return Result.success()
        val (customers, total) = app.repo.overdueSummary(cfg.afterDays)
        if (customers == 0) return Result.success()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        app.prefs.lastReminderDay = today
        val ctx = applicationContext
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("reminders", strRes(ctx, "set.reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, "reminders").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(strRes(ctx, "app.name"))
            .setContentText(strRes(ctx, "rem.toast", customers.toString(), Money.format(total))).setContentIntent(open).setAutoCancel(true).build()
        NotificationManagerCompat.from(ctx).notify(2, n)
        return Result.success()
    }
}
