package com.billmitra.app.data

import androidx.room.withTransaction
import java.time.LocalDate
import java.util.UUID

/** Business-rule violation; [key] is a translation key (same keys as the web app). */
class AppError(val key: String, val args: List<String> = emptyList()) : Exception(key)

fun newId(): String = UUID.randomUUID().toString()

class Repository(private val db: AppDatabase, private val prefs: Prefs) {
    private val dao = db.dao()
    val customers = dao.customers()
    val bills = dao.bills()
    val payments = dao.payments()
    val expenses = dao.expenses()

    /** (number of customers with overdue dues, total overdue amount) for the background reminder. */
    suspend fun overdueSummary(afterDays: Int): Pair<Int, Long> {
        val today = LocalDate.now()
        val paid = dao.allPayments().groupBy { it.billId }.mapValues { e -> e.value.sumOf { it.amount } }
        val overdue = dao.allBills().filter { b ->
            (b.finalAmount - (paid[b.id] ?: 0L)) > 0 && java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(b.date), today) >= afterDays
        }
        return overdue.map { it.customerId }.toSet().size to overdue.sumOf { it.finalAmount - (paid[it.id] ?: 0L) }
    }

    suspend fun saveCustomer(c: Customer) = dao.put(c)

    suspend fun deleteCustomer(id: String) = db.withTransaction {
        if (dao.billCountFor(id) > 0) throw AppError("cust.delBlocked")
        dao.deleteCustomer(id)
    }

    /** Saves a bill. Rejects duplicate numbers and a final amount below what was already received. */
    suspend fun saveBill(b: Bill) = db.withTransaction {
        if (dao.billNoUsed(b.no, b.id) > 0) throw AppError("err.billNoDup")
        val paid = dao.paidForBill(b.id)
        if (b.finalAmount < paid) throw AppError("err.finalBelowPaid", listOf(Money.format(paid)))
        val old = dao.billById(b.id)
        dao.put(b)
        if (old != null && old.customerId != b.customerId) dao.moveBillPayments(b.id, b.customerId)
        val n = Regex("(\\d+)$").find(b.no)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        if (n > prefs.billCounter) prefs.billCounter = n
    }

    suspend fun deleteBill(id: String) = db.withTransaction { dao.deleteBill(id) }   // payments cascade

    /** The sum of payments for a bill can never exceed the bill's final amount. */
    suspend fun savePayment(p: Payment) = db.withTransaction {
        val bill = dao.billById(p.billId) ?: throw AppError("err.bill")
        val others = dao.paidForBillExcept(p.billId, p.id)
        val max = bill.finalAmount - others
        if (p.amount <= 0) throw AppError("err.amount")
        if (p.amount > max) throw AppError("err.overpay", listOf(Money.format(max)))
        dao.put(p.copy(customerId = bill.customerId))
    }

    suspend fun deletePayment(id: String) = dao.deletePayment(id)
    suspend fun saveExpense(e: Expense) = dao.put(e)
    suspend fun deleteExpense(id: String) = dao.deleteExpense(id)

    fun nextBillNo(existing: Set<String>): String {
        val prefix = prefs.profile().prefix
        var n = prefs.billCounter + 1
        while (existing.contains(prefix + n.toString().padStart(4, '0'))) n++
        return prefix + n.toString().padStart(4, '0')
    }

    suspend fun removeDemo() = db.withTransaction {
        val demoBills = dao.allBills().filter { it.demo }.map { it.id }.toSet()
        dao.allPayments().filter { it.billId in demoBills }.forEach { dao.deletePayment(it.id) }
        demoBills.forEach { dao.deleteBill(it) }
        dao.allExpenses().filter { it.demo }.forEach { dao.deleteExpense(it.id) }
        val remaining = dao.allBills()
        dao.allCustomers().filter { c -> c.demo && remaining.none { it.customerId == c.id } }.forEach { dao.deleteCustomer(it.id) }
    }

    suspend fun exportBackup(): String = db.withTransaction {
        Backup.toJson(dao.allCustomers(), dao.allBills(), dao.allPayments(), dao.allExpenses(), prefs)
    }

    suspend fun restore(data: Backup.Parsed) = db.withTransaction {
        dao.clearPayments(); dao.clearBills(); dao.clearCustomers(); dao.clearExpenses()
        dao.putCustomers(data.customers); dao.putBills(data.bills); dao.putPayments(data.payments); dao.putExpenses(data.expenses)
        data.profile?.let { prefs.saveProfile(it) }
        data.reminders?.let { prefs.saveReminders(it) }
        val maxNo = data.bills.maxOfOrNull { Regex("(\\d+)$").find(it.no)?.groupValues?.get(1)?.toLongOrNull() ?: 0L } ?: 0L
        prefs.billCounter = maxOf(data.billCounter, maxNo)
        prefs.seeded = true
    }
}
