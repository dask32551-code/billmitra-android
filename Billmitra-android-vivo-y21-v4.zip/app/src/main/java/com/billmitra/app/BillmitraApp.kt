package com.billmitra.app

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.billmitra.app.data.AppDatabase
import com.billmitra.app.data.Prefs
import com.billmitra.app.data.Repository
import com.billmitra.app.util.ReminderWorker
import java.util.concurrent.TimeUnit

class BillmitraApp : Application() {
    lateinit var prefs: Prefs
    lateinit var repo: Repository

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repo = Repository(AppDatabase.create(this), prefs)
        // once a day, even when the app is closed; the worker itself checks the on/off setting.
        // Done on a background thread so it never delays the first screen.
        Thread {
            WorkManager.getInstance(this).enqueueUniquePeriodicWork("overdue-reminder", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build())
        }.start()
    }
}
