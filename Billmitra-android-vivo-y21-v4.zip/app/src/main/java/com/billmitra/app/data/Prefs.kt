package com.billmitra.app.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class Profile(
    val name: String = "", val owner: String = "", val phone: String = "", val email: String = "",
    val address: String = "", val gstin: String = "", val upi: String = "", val prefix: String = "BM-",
    val gst: Boolean = false, val rateBp: Long = 1800, val footer: String = ""
)

data class ReminderCfg(val enabled: Boolean = true, val afterDays: Int = 7)

/** Small settings store (language is handled by AppCompatDelegate, not here). */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("billmitra", Context.MODE_PRIVATE)

    var theme: String                       // light | dark | system
        get() = sp.getString("theme", "system") ?: "system"
        set(v) = sp.edit().putString("theme", v).apply()
    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(v) = sp.edit().putBoolean("seeded", v).apply()
    var billCounter: Long
        get() = sp.getLong("billCounter", 0)
        set(v) = sp.edit().putLong("billCounter", v).apply()
    var lastReminderDay: String
        get() = sp.getString("remDay", "") ?: ""
        set(v) = sp.edit().putString("remDay", v).apply()

    /** User-added expense categories (names only; stored in expenses as "c:<name>"). */
    var customCats: List<String>
        get() = (sp.getString("cust_cats", "") ?: "").split('\n').filter { it.isNotBlank() }
        set(v) = sp.edit().putString("cust_cats", v.joinToString("\n")).apply()

    fun profile() = Profile(
        sp.getString("p_name", "") ?: "", sp.getString("p_owner", "") ?: "", sp.getString("p_phone", "") ?: "",
        sp.getString("p_email", "") ?: "", sp.getString("p_address", "") ?: "", sp.getString("p_gstin", "") ?: "",
        sp.getString("p_upi", "") ?: "", sp.getString("p_prefix", "BM-") ?: "BM-", sp.getBoolean("p_gst", false),
        sp.getLong("p_rate", 1800), sp.getString("p_footer", "") ?: ""
    )

    fun saveProfile(p: Profile) = sp.edit().putString("p_name", p.name).putString("p_owner", p.owner).putString("p_phone", p.phone)
        .putString("p_email", p.email).putString("p_address", p.address).putString("p_gstin", p.gstin).putString("p_upi", p.upi)
        .putString("p_prefix", p.prefix).putBoolean("p_gst", p.gst).putLong("p_rate", p.rateBp).putString("p_footer", p.footer).apply()

    fun reminders() = ReminderCfg(sp.getBoolean("r_on", true), sp.getInt("r_days", 7))
    fun saveReminders(r: ReminderCfg) = sp.edit().putBoolean("r_on", r.enabled).putInt("r_days", r.afterDays).apply()

    // ---- PIN (PBKDF2 hash + random salt; the PIN itself is never stored) ----
    val hasPin: Boolean get() = sp.contains("pin_hash")
    var biometric: Boolean
        get() = sp.getBoolean("bio", false) && hasPin
        set(v) = sp.edit().putBoolean("bio", v).apply()

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit().putString("pin_salt", salt.toHex()).putString("pin_hash", hash(pin, salt)).apply()
    }
    fun checkPin(pin: String): Boolean {
        val salt = sp.getString("pin_salt", null)?.fromHex() ?: return false
        val expected = sp.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
    }
    fun removePin() = sp.edit().remove("pin_hash").remove("pin_salt").putBoolean("bio", false).apply()

    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded.toHex()
    }
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.fromHex() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
