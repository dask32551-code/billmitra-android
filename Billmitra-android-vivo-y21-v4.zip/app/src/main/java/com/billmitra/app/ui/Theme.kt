package com.billmitra.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0A1F44)
val Navy2 = Color(0xFF12306B)
val Royal = Color(0xFF1D4ED8)

class Extra(val green: Color, val greenBg: Color, val red: Color, val redBg: Color, val amber: Color, val amberBg: Color, val line: Color, val surface2: Color)

val LocalExtra = staticCompositionLocalOf { lightExtra }
private val lightExtra = Extra(Color(0xFF0E8A5F), Color(0xFFE3F5EC), Color(0xFFC2362F), Color(0xFFFCE9E8), Color(0xFFB7791F), Color(0xFFFDF1DC), Color(0xFFE1E7F2), Color(0xFFEEF2F9))
private val darkExtra = Extra(Color(0xFF3FD39A), Color(0xFF12332A), Color(0xFFFF8A82), Color(0xFF3A1B1D), Color(0xFFF4C26B), Color(0xFF3A2D14), Color(0xFF22304D), Color(0xFF18243C))

private val lightScheme = lightColorScheme(
    primary = Royal, onPrimary = Color.White, secondary = Navy, background = Color(0xFFF3F6FB), onBackground = Color(0xFF0F1B33),
    surface = Color.White, onSurface = Color(0xFF0F1B33), surfaceVariant = Color(0xFFEEF2F9), onSurfaceVariant = Color(0xFF5B6B86),
    outline = Color(0xFFE1E7F2), error = Color(0xFFC2362F)
)
private val darkScheme = darkColorScheme(
    primary = Color(0xFF4C7DF5), onPrimary = Color.White, secondary = Color(0xFF9DB8FF), background = Color(0xFF0B1220), onBackground = Color(0xFFE8EEFB),
    surface = Color(0xFF121B2E), onSurface = Color(0xFFE8EEFB), surfaceVariant = Color(0xFF18243C), onSurfaceVariant = Color(0xFF93A3C1),
    outline = Color(0xFF22304D), error = Color(0xFFFF8A82)
)

@Composable
fun BillmitraTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    androidx.compose.runtime.CompositionLocalProvider(LocalExtra provides if (dark) darkExtra else lightExtra) {
        MaterialTheme(
            colorScheme = if (dark) darkScheme else lightScheme,
            typography = Typography().copy(
                titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
                titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            ),
            content = content
        )
    }
}
