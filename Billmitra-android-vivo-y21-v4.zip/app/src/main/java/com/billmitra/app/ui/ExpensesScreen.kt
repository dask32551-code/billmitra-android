@file:OptIn(ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import androidx.compose.foundation.background
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billmitra.app.data.*

@Composable
fun ExpensesScreen(vm: AppViewModel, nav: Nav) {
    val expenses by vm.expenses.collectAsState()
    var cat by rememberSaveable { mutableStateOf("all") }
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    var shown by remember(cat, from, to) { mutableIntStateOf(PAGE_SIZE) }
    val list = remember(expenses, cat, from, to) { expenses.filter { (cat == "all" || it.category == cat) && (from.isEmpty() || it.date >= from) && (to.isEmpty() || it.date <= to) } }
    val total = remember(list) { list.sumOf { it.amount } }; val cash = remember(list) { list.filter { it.method == "cash" }.sumOf { it.amount } }
    val ex = LocalExtra.current
    val allCats = EXPENSE_CATS + (vm.customCats.map { customCatKey(it) } + expenses.map { it.category }.filter { isCustomCat(it) }).distinct()
    Page(tr("nav.expenses"), fab = { GradientFab(Icons.Outlined.Add, tr("exp.add")) { nav.openExpenseForm() } }) {
        item {
            NavyCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(tr("exp.total"), color = Color.White.copy(alpha = .9f)); AnimatedMoney(total, Color.White, 24) }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("method.cash") + ": " + Money.format(cash), color = Color.White.copy(alpha = .85f), fontSize = 13.sp); Text(tr("exp.online") + ": " + Money.format(total - cash), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                }
            }
        }
        item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (listOf("all") + allCats).forEach { k -> PressChip(cat == k, { cat = k }, label = { Text(if (k == "all") tr("common.all") else catName(k)) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(99.dp)) } } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                DateField(tr("common.from"), from, { from = it }, modifier = Modifier.weight(1f)); DateField(tr("common.to"), to, { to = it }, modifier = Modifier.weight(1f))
                if (from.isNotEmpty() || to.isNotEmpty()) IconButton({ from = ""; to = "" }) { Icon(Icons.Outlined.Close, tr("common.clear")) }
            }
        }
        item {
            AppCard() {
                if (list.isEmpty()) EmptyState(Icons.Outlined.Inbox, if (expenses.isEmpty()) tr("exp.empty") else tr("common.noResults"), if (expenses.isEmpty()) tr("exp.emptySub") else null)
                list.take(shown).forEach { e ->
                    ListRow(catIcon(e.category), ex.redBg, ex.red, catName(e.category), fmtDate(e.date) + " · " + tr(if (e.method == "cash") "method.cash" else "exp.online") + (if (e.notes.isNotBlank()) " · " + e.notes else ""),
                        trailing = { Text(Money.format(e.amount), color = ex.red, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, onClick = { nav.openExpenseForm(e.id) })
                }
                ShowMore(list.size, shown) { shown += PAGE_SIZE }
            }
        }
    }
}

@Composable
fun ExpenseForm(vm: AppViewModel, editId: String?, onDismiss: () -> Unit) {
    val expenses by vm.expenses.collectAsState()
    val old = expenses.firstOrNull { it.id == editId }
    var cat by rememberSaveable { mutableStateOf(old?.category ?: "rent") }
    var amount by rememberSaveable { mutableStateOf(old?.let { Money.toInput(it.amount) } ?: "") }
    var date by rememberSaveable { mutableStateOf(old?.date ?: today()) }
    var method by rememberSaveable { mutableStateOf(old?.method ?: "cash") }
    var notes by rememberSaveable { mutableStateOf(old?.notes ?: "") }
    var errs by remember { mutableStateOf(mapOf<String, String>()) }
    var askDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    FormSheet(if (old != null) tr("exp.edit") else tr("exp.add"), onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CategoryField(vm, cat, expenses.map { it.category }.toSet()) { cat = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { MoneyField(tr("exp.amount"), amount, { amount = it }, errs["amount"], Modifier.weight(1f)); DateField(tr("pay.date"), date, { date = it }, errs["date"], Modifier.weight(1f)) }
            Text(tr("pay.method"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ChoiceChips(listOf("cash" to tr("method.cash"), "online" to tr("exp.online")), method) { method = it }
            AppField(tr("pay.notes"), notes, { notes = it }, singleLine = false, optional = true, maxLen = 200)
            FormButtons(onDismiss, {
                val e = mutableMapOf<String, String>(); val amt = Money.parse(amount)
                if (amt == null || amt <= 0) e["amount"] = strRes(ctx, "err.amount")
                if (!isValidDate(date)) e["date"] = strRes(ctx, "err.date")
                errs = e
                if (e.isEmpty()) vm.saveExpense(Expense(old?.id ?: newId(), cat, amt!!, date, method, notes.trim(), old?.createdAt ?: System.currentTimeMillis(), old?.demo ?: false)) { onDismiss() }
            }, extra = { if (old != null) TextButton({ askDelete = true }) { Text(tr("common.delete"), color = LocalExtra.current.red) } })
        }
    }
    if (askDelete && old != null) ConfirmDialog(tr("exp.delTitle"), trf("exp.delMsg", Money.format(old.amount)), tr("common.delete"), { vm.deleteExpense(old.id) { onDismiss() } }, { askDelete = false })
}

fun catIcon(k: String): ImageVector = when (k) {
    "rent" -> Icons.Outlined.Home
    "electricity" -> Icons.Outlined.Bolt
    "salary" -> Icons.Outlined.Payments
    "transport" -> Icons.Outlined.LocalShipping
    "office" -> Icons.Outlined.BusinessCenter
    "other" -> Icons.Outlined.MoreHoriz
    else -> Icons.Outlined.Label
}

/** A tappable field showing the chosen category; opens [CategoryPickerSheet]. */
@Composable
fun CategoryField(vm: AppViewModel, selected: String, usedKeys: Set<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Text(tr("exp.category"), fontSize = 12.sp, color = cs.onSurfaceVariant)
    Surface(Modifier.fillMaxWidth().tap(RoundedCornerShape(14.dp), 0.98f) { open = true }, shape = RoundedCornerShape(14.dp),
        color = cs.surfaceVariant.copy(alpha = .35f), border = BorderStroke(1.dp, cs.outlineVariant)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) { Icon(catIcon(selected), null, tint = cs.primary, modifier = Modifier.size(20.dp)) }
            Text(catName(selected), Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Icon(Icons.Outlined.KeyboardArrowDown, null, tint = cs.onSurfaceVariant)
        }
    }
    if (open) CategoryPickerSheet(vm, selected, usedKeys, { open = false }) { onSelect(it); open = false }
}

@Composable
fun CategoryPickerSheet(vm: AppViewModel, selected: String, usedKeys: Set<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme; val ex = LocalExtra.current; val ctx = LocalContext.current
    var adding by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    val customs = vm.customCats.map { customCatKey(it) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = cs.surface) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(tr("exp.selectCat"), style = MaterialTheme.typography.titleMedium, fontSize = 19.sp)
            Column(Modifier.verticalScroll(rememberScrollState()).weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), maxItemsInEachRow = 3) {
                    (EXPENSE_CATS + customs).forEach { k ->
                        val sel = k == selected
                        Surface(Modifier.weight(1f).tap(RoundedCornerShape(16.dp), 0.95f) { onPick(k) }, shape = RoundedCornerShape(16.dp),
                            color = if (sel) cs.primaryContainer else cs.surfaceVariant.copy(alpha = .35f),
                            border = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant)) {
                            Box {
                                Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(Modifier.size(42.dp).clip(CircleShape).background(if (sel) cs.primary else cs.surface), contentAlignment = Alignment.Center) {
                                        Icon(catIcon(k), null, tint = if (sel) cs.onPrimary else cs.primary, modifier = Modifier.size(22.dp))
                                    }
                                    Text(catName(k), fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                                if (sel) Icon(Icons.Outlined.CheckCircle, null, tint = cs.primary, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
                                if (isCustomCat(k) && k !in usedKeys)
                                    IconButton({ removeTarget = k.substring(CUSTOM_CAT_PREFIX.length) }, Modifier.align(Alignment.TopStart).size(30.dp)) { Icon(Icons.Outlined.Close, tr("cat.rmTitle"), tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp)) }
                            }
                        }
                    }
                    // dashed "add" tile
                    Surface(Modifier.weight(1f).tap(RoundedCornerShape(16.dp), 0.95f) { adding = true }, shape = RoundedCornerShape(16.dp), color = Color.Transparent, border = BorderStroke(1.5.dp, cs.primary.copy(alpha = .6f))) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.size(42.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Add, null, tint = cs.primary, modifier = Modifier.size(22.dp)) }
                            Text(tr("exp.addCat"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.primary, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    // pad the last row so tiles keep equal width
                    val n = EXPENSE_CATS.size + customs.size + 1
                    repeat((3 - n % 3) % 3) { Spacer(Modifier.weight(1f)) }
                }
                AnimatedVisibility(adding) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppField(tr("exp.catName"), name, { name = it; err = null }, err, maxLen = CUSTOM_CAT_MAX)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                            TextButton({ adding = false; name = ""; err = null }) { Text(tr("common.cancel")) }
                            PrimaryButton(tr("exp.catAdd"), onClick = {
                                val e = vm.addCategory(name)
                                if (e != null) err = strRes(ctx, e) else onPick(customCatKey(name.trim().replace(Regex("\\s+"), " ")))
                            })
                        }
                    }
                }
            }
        }
    }
    removeTarget?.let { t -> ConfirmDialog(tr("cat.rmTitle"), trf("cat.rmMsg", t), tr("common.delete"), { vm.removeCategory(t) }, { removeTarget = null }) }
}
