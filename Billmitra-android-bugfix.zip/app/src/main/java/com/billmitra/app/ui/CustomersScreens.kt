@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import androidx.compose.runtime.saveable.rememberSaveable
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billmitra.app.data.*
import com.billmitra.app.util.Share

val GSTIN_RE = Regex("^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
val PHONE_RE = Regex("^\\+?\\d{7,15}$")

@Composable
fun CustomersScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    var q by rememberSaveable { mutableStateOf("") }
    var shown by remember(q) { mutableIntStateOf(PAGE_SIZE) }
    val list = remember(customers, ledger, q) { customers.filter { q.isBlank() || (it.name + " " + it.phone).contains(q.trim(), true) }.sortedWith(compareByDescending<Customer> { ledger.customerDue(it.id) }.thenBy { it.name.lowercase() }) }
    Page(tr("nav.customers"), fab = { GradientFab(Icons.Outlined.PersonAdd, tr("cust.new")) { nav.openCustomerForm() } }) {
        item { NavyCard { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(tr("cust.totalDue"), color = Color.White.copy(alpha = .9f), modifier = Modifier.weight(1f)); AnimatedMoney(ledger.outstanding, Color.White, 22) } } }
        item { SearchBox(q, { q = it }, tr("cust.search")) }
        item {
            AppCard() {
                if (list.isEmpty()) EmptyState(Icons.Outlined.Inbox, if (customers.isEmpty()) tr("cust.empty") else tr("common.noResults"), if (customers.isEmpty()) tr("cust.emptySub") else null)
                list.take(shown).forEach { c ->
                    val due = ledger.customerDue(c.id); val n = ledger.customerBillCount(c.id)
                    ListRow(null, Color.Unspecified, Color.Unspecified, c.name, (c.phone.ifBlank { tr("cust.noPhone") }) + " · " + trf("cust.billsN", n.toString()), leadingText = initialOf(c.name),
                        trailing = { if (due > 0) { Text(Money.format(due), color = LocalExtra.current.red, fontWeight = FontWeight.Bold); StatusChip(PayStatus.UNPAID) } else StatusChip(PayStatus.PAID) },
                        onClick = { nav.customer(c.id) })
                }
                ShowMore(list.size, shown) { shown += PAGE_SIZE }
            }
        }
    }
}

@Composable
fun CustomerDetailScreen(vm: AppViewModel, nav: Nav, id: String) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    val c = customers.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableStateOf("ledger") }
    val ctx = LocalContext.current
    if (c == null) { Page(tr("cust.title"), onBack = nav.back) { item { EmptyState(Icons.Outlined.Inbox, tr("cust.notFound")) } }; return }
    val ex = LocalExtra.current
    val due = ledger.customerDue(id); val paid = ledger.customerPaid(id); val billed = ledger.customerBilled(id)
    val myBills = bills.filter { it.customerId == id }
    val unknown = tr("common.unknown")

    // chronological ledger: each bill debits, each payment credits; running balance
    data class E(val date: String, val order: Int, val at: Long, val bill: Boolean, val ref: String, val amount: Long, val billId: String)
    val entries = (myBills.map { E(it.date, 0, it.createdAt, true, it.no, it.finalAmount, it.id) } +
        payments.filter { it.customerId == id }.map { p -> E(p.date, 1, p.createdAt, false, (bills.firstOrNull { it.id == p.billId }?.no ?: "") + " · " + strRes(ctx, "method." + p.method), p.amount, p.billId) })
        .sortedWith(compareBy<E> { it.date }.thenBy { it.order }.thenBy { it.at })
    var bal = 0L
    val rows = entries.map { e -> bal += if (e.bill) e.amount else -e.amount; e to bal }

    fun reminderText(): String {
        val n = myBills.count { ledger.due(it) > 0 }
        return trfRaw(ctx, "remind.msg", c.name, vm.profile.name.ifBlank { strRes(ctx, "app.name") }, Money.format(due), n.toString())
    }
    Page(c.name, onBack = nav.back) {
        item {
            AppCard {
                if (c.phone.isNotBlank()) Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (c.address.isNotBlank()) Text(c.address, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (c.gstin.isNotBlank()) Text(tr("tax.gstin") + ": " + c.gstin, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                KV(tr("cust.billed"), Money.format(billed)); KV(tr("bill.received"), Money.format(paid), ex.green); KV(tr("cust.outstanding"), Money.format(due), if (due > 0) ex.red else Color.Unspecified, true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                    PrimaryButton(tr("bill.new"), Icons.Outlined.Add) { nav.openBillForm(presetCustomer = id) }
                    if (due > 0) {
                        SoftButton(tr("pay.add"), Icons.Outlined.Payments) { myBills.filter { ledger.due(it) > 0 }.minByOrNull { it.date }?.let { nav.openPaymentForm(billId = it.id) } }
                        val digits = c.phone.filter { it.isDigit() }.let { if (it.length == 10) "91$it" else it }
                        SoftButton(tr("remind.whatsapp"), Icons.Outlined.Message) {
                            if (digits.length >= 8) runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(reminderText()))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { Share.text(ctx, strRes(ctx, "remind.title"), reminderText()) }
                            else Share.text(ctx, strRes(ctx, "remind.title"), reminderText())
                        }
                        SoftButton(tr("remind.sms"), Icons.Outlined.Phone) {
                            if (c.phone.isNotBlank()) runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.phone))).putExtra("sms_body", reminderText()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { Share.text(ctx, strRes(ctx, "remind.title"), reminderText()) }
                            else Share.text(ctx, strRes(ctx, "remind.title"), reminderText())
                        }
                    }
                    SoftButton(tr("common.edit"), Icons.Outlined.Edit) { nav.openCustomerForm(id) }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("ledger", "bills").forEach { k -> PressChip(tab == k, { tab = k }, label = { Text(tr("cust.tab.$k")) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(99.dp)) } } }
        item {
            AppCard {
                if (tab == "ledger") {
                    if (rows.isEmpty()) EmptyState(Icons.Outlined.Inbox, tr("ledger.empty")) else {
                        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                            Text(tr("ledger.entry"), Modifier.weight(1.6f), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            listOf("ledger.debit", "ledger.credit", "ledger.balance").forEach { Text(tr(it), Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        rows.forEach { (e, b) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1.6f)) { Text(tr(if (e.bill) "ledger.bill" else "ledger.payment"), fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(fmtDate(e.date) + " · " + e.ref, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                Text(if (e.bill) Money.format(e.amount) else "–", Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End)
                                Text(if (!e.bill) Money.format(e.amount) else "–", Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End, color = ex.green)
                                Text(Money.format(b), Modifier.weight(1f), fontSize = 12.sp, textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    if (myBills.isEmpty()) EmptyState(Icons.Outlined.Inbox, tr("bills.empty"))
                    myBills.forEach { BillRow(it, ledger, unknown) { nav.bill(it.id) } }
                }
            }
        }
    }
}

private fun trfRaw(ctx: android.content.Context, key: String, vararg a: Any) = strRes(ctx, key, *a)

@Composable
fun CustomerForm(vm: AppViewModel, editId: String?, onDismiss: () -> Unit, onSaved: (String) -> Unit = {}) {
    val bills by vm.bills.collectAsState(); val customers by vm.customers.collectAsState()
    val old = customers.firstOrNull { it.id == editId }
    var name by rememberSaveable { mutableStateOf(old?.name ?: "") }
    var phone by rememberSaveable { mutableStateOf(old?.phone ?: "") }
    var address by rememberSaveable { mutableStateOf(old?.address ?: "") }
    var gstin by rememberSaveable { mutableStateOf(old?.gstin ?: "") }
    var errs by remember { mutableStateOf(mapOf<String, String>()) }
    var askDelete by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val hasBills = old != null && bills.any { it.customerId == old.id }
    FormSheet(if (old != null) tr("cust.edit") else tr("cust.new"), onDismiss) {
        AppField(tr("cust.name"), name, { name = it }, errs["name"], maxLen = 80)
        AppField(tr("cust.phone"), phone, { phone = it }, errs["phone"], KeyboardType.Phone, optional = true, maxLen = 20)
        AppField(tr("cust.address"), address, { address = it }, singleLine = false, optional = true, maxLen = 200)
        AppField(tr("tax.gstin"), gstin, { gstin = it.uppercase() }, errs["gstin"], optional = true, maxLen = 15)
        if (hasBills) Text(tr("cust.delBlocked"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FormButtons(onDismiss, {
            val e = mutableMapOf<String, String>()
            if (name.isBlank()) e["name"] = strRes(ctx, "err.name")
            if (phone.isNotBlank() && !PHONE_RE.matches(phone.replace(" ", "").replace("-", ""))) e["phone"] = strRes(ctx, "err.phone")
            if (gstin.isNotBlank() && !GSTIN_RE.matches(gstin.trim())) e["gstin"] = strRes(ctx, "err.gstin")
            errs = e
            if (e.isEmpty()) { val c = Customer(old?.id ?: newId(), name.trim().replace(Regex("\\s+"), " "), phone.trim(), address.trim(), gstin.trim(), old?.createdAt ?: System.currentTimeMillis(), old?.demo ?: false); vm.saveCustomer(c) { onSaved(it); onDismiss() } }
        }, extra = { if (old != null && !hasBills) TextButton({ askDelete = true }) { Text(tr("common.delete"), color = LocalExtra.current.red) } })
    }
    if (askDelete && old != null) ConfirmDialog(trf("cust.delTitle", old.name), tr("cust.delMsg"), tr("common.delete"), { vm.deleteCustomer(old.id) { onDismiss(); } }, { askDelete = false })
}
