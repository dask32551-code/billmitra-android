package com.billmitra.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.billmitra.app.BillmitraApp
import com.billmitra.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** A message to show: translation key + format arguments. */
data class Msg(val key: String, val args: List<String> = emptyList(), val error: Boolean = false)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as BillmitraApp
    val repo = a.repo
    val prefs = a.prefs

    val customers = repo.customers.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bills = repo.bills.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val payments = repo.payments.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val expenses = repo.expenses.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var profile by mutableStateOf(prefs.profile()); private set
    var reminders by mutableStateOf(prefs.reminders()); private set
    var theme by mutableStateOf(prefs.theme); private set
    var hasPin by mutableStateOf(prefs.hasPin); private set
    var biometric by mutableStateOf(prefs.biometric); private set
    var locked by mutableStateOf(prefs.hasPin)
    var loaded by mutableStateOf(false); private set

    val toasts = MutableSharedFlow<Msg>(extraBufferCapacity = 8)
    val successes = MutableSharedFlow<String>(extraBufferCapacity = 4)

    init {
        viewModelScope.launch {
            if (!prefs.seeded) prefs.seeded = true
            loaded = true
        }
    }

    /** Runs [block]; a business-rule error becomes a toast instead of a crash. Returns true on success. */
    fun run(successKey: String? = null, toastOnly: Boolean = false, onDone: () -> Unit = {}, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                if (successKey != null) { if (toastOnly) toasts.emit(Msg(successKey)) else successes.emit(successKey) }
                onDone()
            } catch (e: AppError) {
                toasts.emit(Msg(e.key, e.args, true))
            } catch (e: Exception) {
                toasts.emit(Msg("err.save", emptyList(), true))
            }
        }
    }

    fun saveCustomer(c: Customer, onDone: (String) -> Unit = {}) = run("ok.customerSaved", toastOnly = true, onDone = { onDone(c.id) }) { repo.saveCustomer(c) }
    fun deleteCustomer(id: String, onDone: () -> Unit) = run("ok.customerDeleted", true, onDone) { repo.deleteCustomer(id) }
    fun saveBill(b: Bill, onDone: () -> Unit) = run("ok.billSaved", onDone = onDone) { repo.saveBill(b) }
    fun deleteBill(id: String, onDone: () -> Unit) = run("ok.billDeleted", true, onDone) { repo.deleteBill(id) }
    fun savePayment(p: Payment, onDone: () -> Unit) = run("ok.paymentSaved", onDone = onDone) { repo.savePayment(p) }
    fun deletePayment(id: String) = run("ok.paymentDeleted", true) { repo.deletePayment(id) }
    fun saveExpense(e: Expense, onDone: () -> Unit) = run("ok.expenseSaved", onDone = onDone) { repo.saveExpense(e) }
    fun deleteExpense(id: String, onDone: () -> Unit) = run("ok.expenseDeleted", true, onDone) { repo.deleteExpense(id) }
    fun removeDemo() = run("demo.removed", true) { repo.removeDemo() }

    fun nextBillNo(): String = repo.nextBillNo(bills.value.map { it.no }.toSet())

    fun saveProfile(p: Profile) { prefs.saveProfile(p); profile = p; viewModelScope.launch { successes.emit("ok.saved") } }
    fun saveReminders(r: ReminderCfg) { prefs.saveReminders(r); reminders = r; viewModelScope.launch { successes.emit("ok.saved") } }
    var customCats by mutableStateOf(prefs.customCats); private set
    /** Returns null on success, or the error string key. */
    fun addCategory(raw: String): String? {
        val name = raw.trim().replace(Regex("\\s+"), " ")
        if (name.isEmpty()) return "err.catEmpty"
        val all = (EXPENSE_CATS.map { it } + customCats.map { customCatKey(it) })
        if (customCats.any { it.equals(name, true) }) return "err.catDup"
        val builtIn = listOf("en", "hi").flatMap { l ->
            val cfg = android.content.res.Configuration(a.resources.configuration); cfg.setLocale(java.util.Locale(l))
            val lc = a.createConfigurationContext(cfg); EXPENSE_CATS.map { strRes(lc, "cat.$it") }
        }
        if (builtIn.any { it.equals(name, true) }) return "err.catDup"
        if (customCats.size >= 30) return "err.catMax"
        customCats = customCats + name; prefs.customCats = customCats
        toast("cat.added")
        return null
    }
    fun removeCategory(name: String) { customCats = customCats - name; prefs.customCats = customCats; toast("cat.removed") }
    @JvmName("applyTheme") fun setTheme(t: String) { prefs.theme = t; theme = t }

    fun setPin(pin: String) { prefs.setPin(pin); hasPin = true; viewModelScope.launch { toasts.emit(Msg("priv.pinSet")) } }
    fun removePin() { prefs.removePin(); hasPin = false; biometric = false; locked = false; viewModelScope.launch { toasts.emit(Msg("priv.pinRemoved")) } }
    fun checkPin(pin: String) = prefs.checkPin(pin)
    /** PBKDF2 is deliberately slow, so the lock screen checks the PIN off the main thread. */
    fun verifyPin(pin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch { onResult(kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { prefs.checkPin(pin) }) }
    }
    @JvmName("applyBiometric") fun setBiometric(on: Boolean) { prefs.biometric = on; biometric = on }
    fun toast(key: String, error: Boolean = false, args: List<String> = emptyList()) { viewModelScope.launch { toasts.emit(Msg(key, args, error)) } }

    suspend fun exportBackup(): String = repo.exportBackup()
    fun restore(text: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try { repo.restore(Backup.parse(text)); profile = prefs.profile(); reminders = prefs.reminders(); successes.emit("bk.restored"); onResult(null) }
            catch (e: Backup.BackupError) { onResult(e.key) } catch (e: Exception) { onResult("corrupt") }
        }
    }
    /** Parses only (no writes) so the UI can confirm before overwriting. */
    fun preview(text: String): Pair<Backup.Parsed?, String?> = try { Backup.parse(text) to null } catch (e: Backup.BackupError) { null to e.key } catch (e: Exception) { null to "corrupt" }
}

/** Derived, always-consistent money figures. Each payment is counted exactly once. */
class Ledger(val bills: List<Bill>, val payments: List<Payment>, val customers: List<Customer>) {
    val paidByBill: Map<String, Long> = payments.groupBy { it.billId }.mapValues { e -> e.value.sumOf { it.amount } }
    fun paid(b: Bill) = paidByBill[b.id] ?: 0L
    fun due(b: Bill) = maxOf(0L, b.finalAmount - paid(b))
    fun status(b: Bill) = payStatus(b.finalAmount, paid(b))
    val outstanding: Long = bills.sumOf { due(it) }
    private val billsByCustomer: Map<String, List<Bill>> = bills.groupBy { it.customerId }
    private val customerById: Map<String, Customer> = customers.associateBy { it.id }
    fun customerBilled(id: String) = (billsByCustomer[id] ?: emptyList()).sumOf { it.finalAmount }
    fun customerDue(id: String) = (billsByCustomer[id] ?: emptyList()).sumOf { due(it) }
    fun customerPaid(id: String) = (billsByCustomer[id] ?: emptyList()).sumOf { paid(it) }
    fun customerBillCount(id: String) = billsByCustomer[id]?.size ?: 0
    fun customer(id: String) = customerById[id]
    fun customerName(id: String, unknown: String) = customer(id)?.name ?: unknown
}

data class Totals(val sales: Long, val bills: Int, val cash: Long, val online: Long, val expenses: Long, val cashExp: Long) {
    val received get() = cash + online
}

fun totals(bills: List<Bill>, payments: List<Payment>, expenses: List<Expense>, from: String?, to: String?): Totals {
    fun ok(d: String) = (from == null || d >= from) && (to == null || d <= to)
    val b = bills.filter { ok(it.date) }
    val p = payments.filter { ok(it.date) }
    val e = expenses.filter { ok(it.date) }
    return Totals(b.sumOf { it.finalAmount }, b.size, p.filter { it.method == "cash" }.sumOf { it.amount },
        p.filter { it.method != "cash" }.sumOf { it.amount }, e.sumOf { it.amount }, e.filter { it.method == "cash" }.sumOf { it.amount })
}
