@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.billmitra.app.ui

import androidx.compose.runtime.saveable.rememberSaveable
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.billmitra.app.data.*
import com.billmitra.app.util.Share
import com.billmitra.app.util.SimplePdf

@Composable
fun BillsScreen(vm: AppViewModel, nav: Nav) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    var q by rememberSaveable { mutableStateOf("") }
    var status by rememberSaveable { mutableStateOf("all") }
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    val unknown = tr("common.unknown")
    var shown by remember(status, from, to, q) { mutableIntStateOf(PAGE_SIZE) }
    val list = remember(bills, ledger, status, from, to, q, unknown) { bills.filter { b ->
        (status == "all" || ledger.status(b).name.lowercase() == status) && (from.isEmpty() || b.date >= from) && (to.isEmpty() || b.date <= to) &&
            (q.isBlank() || (b.no + " " + ledger.customerName(b.customerId, unknown) + " " + b.description).contains(q.trim(), ignoreCase = true))
    } }
    Page(tr("nav.bills"), fab = { GradientFab(Icons.Outlined.Add, tr("bill.new")) { nav.openBillForm() } }) {
        item { SearchBox(q, { q = it }, tr("bills.search")) }
        item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("all", "paid", "partial", "unpaid").forEach { s -> FilterChip(status == s, { status = s }, label = { Text(if (s == "all") tr("common.all") else tr("status.$s")) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(99.dp)) } } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                DateField(tr("common.from"), from, { from = it }, modifier = Modifier.weight(1f)); DateField(tr("common.to"), to, { to = it }, modifier = Modifier.weight(1f))
                if (from.isNotEmpty() || to.isNotEmpty()) IconButton({ from = ""; to = "" }) { Icon(Icons.Outlined.Close, tr("common.clear")) }
            }
        }
        item {
            AppCard() {
                if (list.isEmpty()) EmptyState(Icons.Outlined.Inbox, if (bills.isEmpty()) tr("bills.empty") else tr("common.noResults"), if (bills.isEmpty()) tr("bills.emptySub") else null)
                list.take(shown).forEach { BillRow(it, ledger, unknown) { nav.bill(it.id) } }
                ShowMore(list.size, shown) { shown += PAGE_SIZE }
            }
        }
    }
}

@Composable
fun BillDetailScreen(vm: AppViewModel, nav: Nav, id: String) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    val bill = bills.firstOrNull { it.id == id }
    val ctx = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    if (bill == null) { Page(tr("bill.title"), onBack = nav.back) { item { EmptyState(Icons.Outlined.Inbox, tr("bill.notFound")) } }; return }
    val ex = LocalExtra.current
    val pays = payments.filter { it.billId == id }.sortedBy { it.date }
    val calc = bill.calc()
    val due = ledger.due(bill); val paid = ledger.paid(bill)
    val cust = ledger.customer(bill.customerId)
    Page(bill.no, onBack = nav.back) {
        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                    Column { Text(tr("bill.customer"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton({ nav.customer(bill.customerId) }, contentPadding = PaddingValues(0.dp)) { Text(cust?.name ?: tr("common.unknown"), fontSize = 18.sp, fontWeight = FontWeight.Bold) } }
                    StatusChip(ledger.status(bill))
                }
                Text(fmtDate(bill.date), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (bill.description.isNotBlank()) Text(bill.description, Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(8.dp))
                KV(tr("bill.amount"), Money.format(calc.amount))
                if (calc.discount > 0) KV(tr("bill.discount"), "−" + Money.format(calc.discount))
                if (bill.gst) {
                    KV(tr("bill.taxable"), Money.format(calc.base))
                    if (!bill.intra) KV(tr("tax.igst") + " ${rateLabel(bill.rateBp)}%", Money.format(calc.igst)) else { KV(tr("tax.cgst") + " ${halfRateLabel(bill.rateBp)}%", Money.format(calc.cgst)); KV(tr("tax.sgst") + " ${halfRateLabel(bill.rateBp)}%", Money.format(calc.sgst)) }
                }
                KV(tr("bill.final"), Money.format(bill.finalAmount), big = true)
                KV(tr("bill.received"), Money.format(paid), ex.green)
                KV(tr("bill.due"), Money.format(due), if (due > 0) ex.red else Color.Unspecified, big = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 8.dp)) {
                    if (due > 0) PrimaryButton(tr("pay.add"), Icons.Outlined.Add) { nav.openPaymentForm(billId = id) }
                    SoftButton(tr("bill.pdf"), Icons.Outlined.Print) { Share.file(ctx, "bill-${bill.no}.pdf", "application/pdf", billPdf(ctx, bill, cust, pays, vm.profile, paid, due), strRes(ctx, "common.share")) }
                    SoftButton(tr("common.share"), Icons.Outlined.Share) { Share.text(ctx, bill.no, billText(ctx, bill, cust, vm.profile, paid, due)) }
                    SoftButton(tr("common.edit"), Icons.Outlined.Edit) { nav.openBillForm(editId = id) }
                    SoftButton(tr("common.delete"), Icons.Outlined.Delete, danger = true) { confirmDelete = true }
                }
            }
        }
        item {
            AppCard {
                SectionTitle(tr("pay.history"))
                if (pays.isEmpty()) EmptyState(Icons.Outlined.Inbox, tr("pay.none"))
                pays.forEach { p ->
                    ListRow(if (p.method == "cash") Icons.Outlined.Payments else Icons.Outlined.PhoneAndroid, ex.greenBg, ex.green, tr("method." + p.method),
                        fmtDate(p.date) + (if (p.ref.isNotBlank()) " · " + p.ref else "") + (if (p.notes.isNotBlank()) " · " + p.notes else ""),
                        trailing = {
                            Text(Money.format(p.amount), color = ex.green, fontWeight = FontWeight.Bold)
                            Row { IconButton({ nav.openPaymentForm(paymentId = p.id) }, Modifier.size(32.dp)) { Icon(Icons.Outlined.Edit, tr("common.edit"), Modifier.size(18.dp)) }
                                IconButton({ delPay = p }, Modifier.size(32.dp)) { Icon(Icons.Outlined.Delete, tr("common.delete"), Modifier.size(18.dp)) } }
                        })
                }
            }
        }
    }
    if (confirmDelete) ConfirmDialog(trf("bill.delTitle", bill.no), if (pays.isEmpty()) tr("bill.delMsg") else trf("bill.delMsgPay", pays.size.toString(), Money.format(paid)), tr("common.delete"),
        { vm.deleteBill(id) { nav.back() } }, { confirmDelete = false })
    delPay?.let { p -> ConfirmDialog(tr("pay.delTitle"), trf("pay.delMsg", Money.format(p.amount)), tr("common.delete"), { vm.deletePayment(p.id) }, { delPay = null }) }
}

/** Plain-text bill summary for sharing. */
private fun billText(ctx: Context, b: Bill, c: Customer?, p: Profile, paid: Long, due: Long): String = listOf(
    p.name.ifBlank { strRes(ctx, "app.name") }, strRes(ctx, "bill.title") + ": " + b.no + " (" + b.date + ")", strRes(ctx, "bill.customer") + ": " + (c?.name ?: ""),
    strRes(ctx, "bill.final") + ": " + Money.format(b.finalAmount), strRes(ctx, "bill.received") + ": " + Money.format(paid), strRes(ctx, "bill.due") + ": " + Money.format(due)).joinToString("\n")

private fun billPdf(ctx: Context, b: Bill, c: Customer?, pays: List<Payment>, p: Profile, paid: Long, due: Long): ByteArray {
    val s = { k: String -> strRes(ctx, k) }
    val k = b.calc()
    val pdf = SimplePdf()
    pdf.line(p.name.ifBlank { s("app.name") }, big = true)
    if (p.address.isNotBlank()) pdf.line(p.address, mutedText = true)
    if (p.phone.isNotBlank()) pdf.line(s("profile.phone") + ": " + p.phone, mutedText = true)
    if (b.gst && p.gstin.isNotBlank()) pdf.line(s("tax.gstin") + ": " + p.gstin, mutedText = true)
    pdf.rule()
    pdf.line(if (b.gst) s("inv.tax") else s("inv.bill"), boldText = true)
    pdf.row(s("bill.no") + ": " + b.no, s("bill.date") + ": " + b.date)
    pdf.space()
    pdf.line(s("inv.billTo"), mutedText = true)
    pdf.line(c?.name ?: "", boldText = true)
    if (!c?.phone.isNullOrBlank()) pdf.line(c!!.phone)
    if (!c?.address.isNullOrBlank()) pdf.line(c!!.address)
    if (b.gst && !c?.gstin.isNullOrBlank()) pdf.line(s("tax.gstin") + ": " + c!!.gstin)
    pdf.space(); pdf.rule()
    pdf.row(b.description.ifBlank { "—" }, Money.format(k.amount))
    if (k.discount > 0) pdf.row(s("bill.discount"), "−" + Money.format(k.discount))
    if (b.gst) {
        pdf.row(s("bill.taxable"), Money.format(k.base))
        if (!b.intra) pdf.row(s("tax.igst"), Money.format(k.igst)) else { pdf.row(s("tax.cgst"), Money.format(k.cgst)); pdf.row(s("tax.sgst"), Money.format(k.sgst)) }
    }
    pdf.rule()
    pdf.row(s("bill.final"), Money.format(b.finalAmount), true)
    pdf.row(s("bill.received"), Money.format(paid))
    pdf.row(s("bill.due"), Money.format(due), true)
    if (pays.isNotEmpty()) { pdf.space(); pdf.line(s("pay.history"), boldText = true); pays.forEach { pdf.row(it.date + " · " + s("method." + it.method) + (if (it.ref.isNotBlank()) " · " + it.ref else ""), Money.format(it.amount)) } }
    if (p.upi.isNotBlank() && due > 0) { pdf.space(); pdf.line(s("tax.upi") + ": " + p.upi, boldText = true) }
    if (p.footer.isNotBlank()) { pdf.space(); pdf.line(p.footer, mutedText = true) }
    pdf.space(); pdf.line(s("inv.generated"), mutedText = true)
    return pdf.toBytes()
}

/* ------------------------- forms ------------------------- */
@Composable
fun BillForm(vm: AppViewModel, editId: String?, presetCustomer: String?, onDismiss: () -> Unit) {
    val bills by vm.bills.collectAsState(); val customers by vm.customers.collectAsState()
    val old = bills.firstOrNull { it.id == editId }
    val p = vm.profile
    var customerId by rememberSaveable { mutableStateOf(old?.customerId ?: presetCustomer ?: "") }
    var no by rememberSaveable { mutableStateOf(old?.no ?: vm.nextBillNo()) }
    var date by rememberSaveable { mutableStateOf(old?.date ?: today()) }
    var desc by rememberSaveable { mutableStateOf(old?.description ?: "") }
    var amount by rememberSaveable { mutableStateOf(old?.let { Money.toInput(it.amount) } ?: "") }
    var discount by rememberSaveable { mutableStateOf(old?.takeIf { it.discount > 0 }?.let { Money.toInput(it.discount) } ?: "") }
    var gst by rememberSaveable { mutableStateOf(old?.gst ?: p.gst) }
    var rate by rememberSaveable { mutableStateOf(rateLabel(old?.rateBp ?: p.rateBp)) }
    var intra by rememberSaveable { mutableStateOf(old?.intra ?: true) }
    var errs by remember { mutableStateOf(mapOf<String, String>()) }
    var newCust by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val a = Money.parse(amount); val d = if (discount.isBlank()) 0L else Money.parse(discount); val r = if (!gst) 0L else Money.parse(rate)
    val previewOk = a != null && a > 0 && d != null && d < a && (!gst || (r != null && r <= 10000))
    val calc = if (previewOk) calcBill(a!!, d!!, gst, r ?: 0, intra) else null

    FormSheet(if (old != null) tr("bill.edit") else tr("bill.new"), onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(menu, { menu = it }, Modifier.weight(1f)) {
                    OutlinedTextField(customers.firstOrNull { it.id == customerId }?.name ?: "", {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text(tr("bill.customer")) },
                        isError = errs["customer"] != null, supportingText = errs["customer"]?.let { { Text(it) } }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menu) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                    ExposedDropdownMenu(menu, { menu = false }) { customers.forEach { c -> DropdownMenuItem({ Text(c.name) }, { customerId = c.id; menu = false }) } }
                }
                FilledTonalIconButton({ newCust = true }, Modifier.padding(top = 8.dp)) { Icon(Icons.Outlined.PersonAdd, tr("cust.new")) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppField(tr("bill.no"), no, { no = it }, errs["no"], modifier = Modifier.weight(1f), maxLen = 30)
                DateField(tr("bill.date"), date, { date = it }, errs["date"], Modifier.weight(1f))
            }
            AppField(tr("bill.description"), desc, { desc = it }, errs["desc"], singleLine = false, optional = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField(tr("bill.amount"), amount, { amount = it }, errs["amount"], Modifier.weight(1f))
                MoneyField(tr("bill.discount"), discount, { discount = it }, errs["discount"], Modifier.weight(1f))
            }
            Text(tr("bill.taxType"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ChoiceChips(listOf("none" to tr("bill.noGst"), "gst" to tr("tax.gst")), if (gst) "gst" else "none") { gst = it == "gst" }
            if (gst) {
                AppField(tr("bill.gstRate") + " (%)", rate, { v -> if (v.all { it.isDigit() || it == '.' }) rate = v }, errs["rate"], KeyboardType.Decimal, maxLen = 6)
                ChoiceChips(listOf(5, 12, 18, 28).map { "$it" to "$it%" }, rate) { rate = it }
                Text(tr("bill.supply"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ChoiceChips(listOf("intra" to tr("bill.intra"), "inter" to tr("bill.inter")), if (intra) "intra" else "inter") { intra = it == "intra" }
            }
            AppCard {
                if (calc == null) Text(tr("bill.previewHint"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) else {
                    KV(tr("bill.amount"), Money.format(calc.amount))
                    if (calc.discount > 0) KV(tr("bill.discount"), "−" + Money.format(calc.discount))
                    if (gst) { if (!intra) KV(tr("tax.igst"), Money.format(calc.igst)) else { KV(tr("tax.cgst"), Money.format(calc.cgst)); KV(tr("tax.sgst"), Money.format(calc.sgst)) } }
                    KV(tr("bill.final"), Money.format(calc.final), big = true)
                }
            }
            FormButtons(onDismiss, {
                val e = mutableMapOf<String, String>()
                if (customerId.isEmpty()) e["customer"] = strRes(ctx, "err.customer")
                if (no.isBlank()) e["no"] = strRes(ctx, "err.billNo") else if (bills.any { it.no.equals(no.trim(), true) && it.id != old?.id }) e["no"] = strRes(ctx, "err.billNoDup")
                if (!isValidDate(date)) e["date"] = strRes(ctx, "err.date")
                if (a == null || a <= 0) e["amount"] = strRes(ctx, "err.amount")
                if (d == null) e["discount"] = strRes(ctx, "err.discount") else if (a != null && a > 0 && d >= a) e["discount"] = strRes(ctx, "err.discountBig")
                if (gst && (r == null || r > 10000)) e["rate"] = strRes(ctx, "err.rate")
                errs = e
                if (e.isEmpty()) {
                    val k = calcBill(a!!, d!!, gst, r ?: 0, intra)
                    vm.saveBill(Bill(old?.id ?: newId(), no.trim(), customerId, date, desc.trim(), k.amount, k.discount, gst, if (gst) r!! else 0, intra, k.tax, k.final, old?.createdAt ?: System.currentTimeMillis(), old?.demo ?: false)) { onDismiss() }
                }
            })
        }
    }
    if (newCust) CustomerForm(vm, null, { newCust = false }) { id -> customerId = id }
}

@Composable
fun PaymentForm(vm: AppViewModel, billId: String?, paymentId: String?, onDismiss: () -> Unit) {
    val bills by vm.bills.collectAsState(); val payments by vm.payments.collectAsState(); val customers by vm.customers.collectAsState()
    val ledger = remember(bills, payments, customers) { Ledger(bills, payments, customers) }
    val editing = payments.firstOrNull { it.id == paymentId }
    val owing = bills.filter { ledger.due(it) > 0 || it.id == editing?.billId }
    val ctx = LocalContext.current
    if (billId == null && editing == null && owing.isEmpty()) { LaunchedEffect(Unit) { vm.toast("pay.noDue"); onDismiss() }; return }
    var selBill by rememberSaveable { mutableStateOf(editing?.billId ?: billId ?: "") }
    val bill = bills.firstOrNull { it.id == selBill }
    val maxPay = bill?.let { ledger.due(it) + (if (editing != null && editing.billId == it.id) editing.amount else 0L) } ?: 0L
    var amount by rememberSaveable { mutableStateOf(editing?.let { Money.toInput(it.amount) } ?: bill?.let { Money.toInput(ledger.due(it)) } ?: "") }
    var date by rememberSaveable { mutableStateOf(editing?.date ?: today()) }
    var method by rememberSaveable { mutableStateOf(editing?.method ?: "cash") }
    var ref by rememberSaveable { mutableStateOf(editing?.ref ?: "") }
    var notes by rememberSaveable { mutableStateOf(editing?.notes ?: "") }
    var errs by remember { mutableStateOf(mapOf<String, String>()) }
    var menu by remember { mutableStateOf(false) }
    val unknown = tr("common.unknown")

    FormSheet(if (editing != null) tr("pay.edit") else tr("pay.add"), onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (billId != null || editing != null) {
                if (bill != null) AppCard { Text(bill.no + " · " + ledger.customerName(bill.customerId, unknown), fontWeight = FontWeight.Bold); Text(tr("bill.due") + ": " + Money.format(maxPay), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                ExposedDropdownMenuBox(menu, { menu = it }) {
                    OutlinedTextField(bill?.let { it.no + " · " + ledger.customerName(it.customerId, unknown) } ?: "", {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text(tr("pay.forBill")) },
                        isError = errs["bill"] != null, supportingText = errs["bill"]?.let { { Text(it) } }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menu) }, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                    ExposedDropdownMenu(menu, { menu = false }) {
                        owing.forEach { b -> DropdownMenuItem({ Text(b.no + " · " + ledger.customerName(b.customerId, unknown) + " · " + Money.format(ledger.due(b))) }, { selBill = b.id; amount = Money.toInput(ledger.due(b)); menu = false }) }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField(tr("pay.amount"), amount, { amount = it }, errs["amount"], Modifier.weight(1f))
                DateField(tr("pay.date"), date, { date = it }, errs["date"], Modifier.weight(1f))
            }
            Text(tr("pay.method"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ChoiceChips(PAY_METHODS.map { it to tr("method.$it") }, method) { method = it }
            AppField(tr("pay.ref"), ref, { ref = it }, optional = true, maxLen = 60)
            AppField(tr("pay.notes"), notes, { notes = it }, singleLine = false, optional = true, maxLen = 200)
            FormButtons(onDismiss, {
                val e = mutableMapOf<String, String>()
                val amt = Money.parse(amount)
                if (bill == null) e["bill"] = strRes(ctx, "err.bill")
                if (amt == null || amt <= 0) e["amount"] = strRes(ctx, "err.amount") else if (bill != null && amt > maxPay) e["amount"] = strRes(ctx, "err.overpay", Money.format(maxPay))
                if (!isValidDate(date)) e["date"] = strRes(ctx, "err.date")
                errs = e
                if (e.isEmpty()) vm.savePayment(Payment(editing?.id ?: newId(), bill!!.id, bill.customerId, date, method, amt!!, ref.trim(), notes.trim(), editing?.createdAt ?: System.currentTimeMillis(), editing?.demo ?: false)) { onDismiss() }
            })
        }
    }
}
