package com.billmitra.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File

object Csv {
    private fun cell(v: Any?): String {
        var s = v?.toString() ?: ""
        if (v is String && s.isNotEmpty() && s[0] in "=+-@\t\r") s = "'$s"          // block spreadsheet formula injection
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }
    fun build(rows: List<List<Any?>>): String = "﻿" + rows.joinToString("\r\n") { r -> r.joinToString(",") { cell(it) } }
}

object Share {
    /** Writes [bytes] into the app cache and opens the system share sheet. */
    fun file(ctx: Context, name: String, mime: String, bytes: ByteArray, title: String) {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val f = File(dir, name).also { it.writeBytes(bytes) }
        val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun text(ctx: Context, title: String, body: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) }
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Minimal A4 PDF writer for bills and reports (uses the system font, so Devanagari renders). */
class SimplePdf {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvasY = 0f
    private var pageNo = 0
    private val w = 595; private val h = 842; private val m = 40f
    private val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = 0xFF111111.toInt() }
    private val bold = TextPaint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
    private val title = TextPaint(bold).apply { textSize = 20f; color = 0xFF0A1F44.toInt() }
    private val muted = TextPaint(normal).apply { color = 0xFF667788.toInt(); textSize = 10f }

    private fun ensure(space: Float) {
        if (page == null || canvasY + space > h - m) {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            canvasY = m
        }
    }
    private fun paint(b: Boolean, big: Boolean, mut: Boolean) = when { big -> title; b -> bold; mut -> muted; else -> normal }

    fun line(text: String, boldText: Boolean = false, big: Boolean = false, mutedText: Boolean = false) {
        val p = paint(boldText, big, mutedText)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, p, (w - 2 * m).toInt()).build()
        ensure(layout.height + 4f)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        canvasY += layout.height + 4f
    }
    /** left label (wraps if long), right-aligned value */
    fun row(left: String, right: String, boldText: Boolean = false) {
        val p = paint(boldText, false, false)
        val rightW = p.measureText(right)
        val leftW = (w - 2 * m - rightW - 12f).toInt().coerceAtLeast(60)
        val layout = StaticLayout.Builder.obtain(left, 0, left.length, p, leftW).build()
        val rowH = maxOf(layout.height.toFloat(), 14f) + 4f
        ensure(rowH)
        val c = page!!.canvas
        c.save(); c.translate(m, canvasY); layout.draw(c); c.restore()
        c.drawText(right, w - m - rightW, canvasY + 12f, p)
        canvasY += rowH
    }
    /** Section heading with a light band behind it. */
    fun heading(text: String) {
        ensure(26f); space(4f)
        val c = page!!.canvas
        c.drawRect(m, canvasY, w - m, canvasY + 20f, Paint().apply { color = 0xFFEAF0FA.toInt() })
        c.drawText(text, m + 6f, canvasY + 14f, bold)
        canvasY += 24f
    }
    /** Three big boxes side by side: label on top, amount below. */
    fun bigBoxes(items: List<Triple<String, String, Int>>) {
        val gap = 8f; val bw = (w - 2 * m - gap * (items.size - 1)) / items.size; val bh = 52f
        ensure(bh + 8f)
        val c = page!!.canvas
        items.forEachIndexed { i, (label, value, color) ->
            val x = m + i * (bw + gap)
            c.drawRect(x, canvasY, x + bw, canvasY + bh, Paint().apply { this.color = 0xFFF4F6FA.toInt() })
            c.drawRect(x, canvasY, x + 4f, canvasY + bh, Paint().apply { this.color = color })
            c.drawText(label, x + 12f, canvasY + 18f, muted)
            c.drawText(value, x + 12f, canvasY + 41f, TextPaint(bold).apply { textSize = 17f; this.color = color })
        }
        canvasY += bh + 8f
    }
    /** Table row: first column left-aligned, the rest right-aligned. [weights] are relative column widths. */
    fun cols(cells: List<String>, weights: List<Float>, boldText: Boolean = false, shade: Boolean = false) {
        val p = paint(boldText, false, false); val total = w - 2 * m; val sum = weights.sum()
        ensure(20f)
        val c = page!!.canvas
        if (shade) c.drawRect(m, canvasY - 2f, w - m, canvasY + 16f, Paint().apply { color = 0xFFEAF0FA.toInt() })
        var x = m
        cells.forEachIndexed { i, t ->
            val cw = total * weights[i] / sum
            if (i == 0) c.drawText(t, x + 4f, canvasY + 11f, p) else c.drawText(t, x + cw - 4f - p.measureText(t), canvasY + 11f, p)
            x += cw
        }
        val line = Paint().apply { color = 0xFFDDE3EC.toInt(); strokeWidth = 0.7f }
        c.drawLine(m, canvasY + 17f, w - m, canvasY + 17f, line)
        canvasY += 20f
    }
    fun rule() { ensure(10f); val c = page!!.canvas; val pt = Paint().apply { color = 0xFF0A1F44.toInt(); strokeWidth = 1.5f }; c.drawLine(m, canvasY + 4f, w - m, canvasY + 4f, pt); canvasY += 10f }
    fun space(px: Float = 8f) { canvasY += px }

    fun toBytes(): ByteArray {
        page?.let { doc.finishPage(it) }
        val out = java.io.ByteArrayOutputStream()
        doc.writeTo(out); doc.close()
        return out.toByteArray()
    }
}
